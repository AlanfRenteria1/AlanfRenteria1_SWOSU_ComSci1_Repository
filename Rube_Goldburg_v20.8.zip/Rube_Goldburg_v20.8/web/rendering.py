"""Render browser game sessions into the HTML page template."""

import html
from pathlib import Path

from web.config import ACTION_ART, SCENE_ART
from web.endings import ENDING_DETAILS
from web.models import Page
from web.pages import PAGES


TEMPLATE_PATH = Path(__file__).resolve().parent / "templates" / "page.html"
TEMPLATE = TEMPLATE_PATH.read_text(encoding="utf-8")


def render_page(session: dict[str, str]) -> bytes:
    page: Page = PAGES[session["scene"]]
    scene = session["scene"]
    action = session.get("last_action", "")
    ending_id = session.get("ending_id", "")
    image_name, image_description = ACTION_ART.get(action, SCENE_ART[scene])
    title = page["name"]
    description = page["description"]
    if scene in {"ending", "backrooms"}:
        title, description = ENDING_DETAILS.get(ending_id, ENDING_DETAILS["default"])
        image_name, image_description = "game-over.svg", "Illustration of a temporal game over"
    message = html.escape(session.get("message", ""))

    choices_html = "".join(
        '<button type="submit" name="action" value="{}">{}</button>'.format(
            html.escape(choice["id"], quote=True),
            html.escape(choice["name"]),
        )
        for choice in page["choices"]
    )
    illustration_html = (
        f'<img class="illustration" src="/Web_Assets/{image_name}" '
        f'alt="{html.escape(image_description, quote=True)}">'
    )
    message_html = f'<p class="message" role="status">{message}</p>' if message else ""

    replacements = {
        "{{title}}": html.escape(title),
        "{{description}}": html.escape(description),
        "{{scene_id}}": html.escape(page["id"], quote=True),
        "{{action_id}}": html.escape(action, quote=True),
        "{{ending_id}}": html.escape(ending_id, quote=True),
        "{{illustration}}": illustration_html,
        "{{message}}": message_html,
        "{{choices}}": choices_html,
    }
    document = TEMPLATE
    for placeholder, value in replacements.items():
        document = document.replace(placeholder, value)
    return document.encode("utf-8")
