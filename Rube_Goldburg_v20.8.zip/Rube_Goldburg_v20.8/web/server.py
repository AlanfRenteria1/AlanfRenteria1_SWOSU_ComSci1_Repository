"""HTTP server and request handlers for the local browser game."""

import secrets
import threading
import webbrowser
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from web.config import (
    HOST,
    PORT,
    STATIC_DIR,
    STATIC_FILES,
    WEB_ASSET_DIR,
    WEB_ASSET_FILES,
)
from web.game import new_session, respond
from web.rendering import render_page


SESSIONS: dict[str, dict[str, str]] = {}
SESSIONS_LOCK = threading.Lock()


class GameHandler(BaseHTTPRequestHandler):
    server_version = "TemporalFacility/1.0"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def session(self) -> tuple[str, dict[str, str], bool]:
        cookie = cookies.SimpleCookie(self.headers.get("Cookie"))
        morsel = cookie.get("facility_session")
        session_id = morsel.value if morsel else ""
        if session_id:
            with SESSIONS_LOCK:
                session = SESSIONS.get(session_id)
                if session is not None:
                    return session_id, session, False

        session_id = secrets.token_urlsafe(24)
        session = new_session()
        with SESSIONS_LOCK:
            SESSIONS[session_id] = session
        return session_id, session, True

    def send_page(self, session_id: str, session: dict[str, str], set_cookie: bool) -> None:
        body = render_page(session)
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if set_cookie:
            self.send_header(
                "Set-Cookie",
                f"facility_session={session_id}; HttpOnly; SameSite=Lax; Path=/",
            )
        self.end_headers()
        self.wfile.write(body)

    def send_asset(self, directory: Path, filename: str, content_type: str) -> None:
        try:
            body = (directory / filename).read_bytes()
        except OSError:
            self.send_error(500, "Game asset could not be loaded")
            return

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        request_path = urlsplit(self.path).path
        if request_path.startswith("/Web_Assets/"):
            asset_name = request_path.removeprefix("/Web_Assets/")
            filename = WEB_ASSET_FILES.get(asset_name)
            if filename is None:
                self.send_error(404)
                return
            self.send_asset(WEB_ASSET_DIR, filename, "image/svg+xml; charset=utf-8")
            return

        if request_path.startswith("/static/"):
            asset_name = request_path.removeprefix("/static/")
            asset = STATIC_FILES.get(asset_name)
            if asset is None:
                self.send_error(404)
                return
            filename, content_type = asset
            self.send_asset(STATIC_DIR, filename, content_type)
            return

        if request_path not in {"/", "/index.html"}:
            self.send_error(404)
            return
        session_id, session, set_cookie = self.session()
        self.send_page(session_id, session, set_cookie)

    def do_POST(self) -> None:
        if self.path != "/action":
            self.send_error(404)
            return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_error(400, "Invalid form submission")
            return
        if content_length < 0 or content_length > 4096:
            self.send_error(413, "Form submission is too large")
            return

        body = self.rfile.read(content_length).decode("utf-8", errors="replace")
        values = parse_qs(body, keep_blank_values=False).get("action", [])
        if not values:
            self.send_error(400, "Missing action")
            return

        session_id, session, set_cookie = self.session()
        with SESSIONS_LOCK:
            respond(session, values[0])
            self.send_page(session_id, session, set_cookie)


def run_server() -> None:
    server = ThreadingHTTPServer((HOST, PORT), GameHandler)
    url = f"http://{HOST}:{PORT}/"
    print(f"Temporal Calculation Facility is running at {url}")
    print("Press Ctrl+C to stop the server.")
    try:
        webbrowser.open(url)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
