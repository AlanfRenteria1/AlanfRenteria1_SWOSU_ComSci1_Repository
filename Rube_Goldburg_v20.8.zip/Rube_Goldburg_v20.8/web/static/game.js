(() => {
  let audioContext;
  const cues = {
    pull: [660, 880, 1175],
    tap: [440, 392],
    use_beam: [440, 660, 880, 1320],
    vapuration: [220, 330, 220],
    red_wire: [880, 1175],
    blue_wire: [220, 165],
    green_wire: [220, 165],
    fate: [523, 784],
    print: [600, 440, 600],
    search: [740, 988],
    squirrel: [660, 880],
    red_button: [180, 130],
    tools: [360, 480],
    power: [180, 240, 360],
    vent: [260, 390],
    cubicles: [520, 620],
    meeting: [440, 550],
    coffee_machine: [620, 740, 880],
    microwave: [440, 520],
    fridge: [310, 390],
    recover: [520, 880, 1320],
    left_button: [180, 140, 90],
    right_button: [523, 659, 784],
    disco: [659, 784, 988, 1175],
    wall: [440, 330, 220],
    door: [480, 430],
    floor: [220, 180],
    weekday: [523, 659, 784],
    training: [320, 340, 300],
    squirrel_help: [660, 740, 880],
    inspect_beam: [440, 660, 880],
    cycle: [390, 520, 650],
    inspect_pipes: [330, 440],
    warning: [440, 330],
    meeting_chair: [480, 560],
    meeting_board: [520, 390],
    paper: [520, 420],
    toner: [430, 350],
    polite: [660, 520]
  };

  function playSound(action) {
    const AudioContextType = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextType) return;

    try {
      audioContext ||= new AudioContextType();
      if (audioContext.state === "suspended") {
        audioContext.resume().catch((error) => console.warn("Audio could not resume:", error));
      }

      const notes = cues[action] || [520, 690];
      notes.forEach((frequency, index) => {
        const start = audioContext.currentTime + index * .085;
        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();
        oscillator.type = action === "vapuration" || action === "red_button" ? "sawtooth" : "sine";
        oscillator.frequency.setValueAtTime(frequency, start);
        gain.gain.setValueAtTime(.0001, start);
        gain.gain.exponentialRampToValueAtTime(.055, start + .012);
        gain.gain.exponentialRampToValueAtTime(.0001, start + .12);
        oscillator.connect(gain);
        gain.connect(audioContext.destination);
        oscillator.start(start);
        oscillator.stop(start + .13);
      });
    } catch (error) {
      console.warn("Sound effects could not be played:", error);
    }
  }

  document.addEventListener("submit", async (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.action !== location.origin + "/action") return;
    event.preventDefault();

    const button = event.submitter;
    if (!(button instanceof HTMLButtonElement)) return;
    button.disabled = true;
    button.classList.add("selected");
    playSound(button.value);

    const payload = new URLSearchParams({ action: button.value });
    try {
      const response = await fetch(form.action, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
        body: payload
      });
      if (!response.ok) throw new Error(`Server returned ${response.status}`);

      const nextDocument = new DOMParser().parseFromString(await response.text(), "text/html");
      const nextMain = nextDocument.querySelector("main");
      const currentMain = document.querySelector("main");
      if (!nextMain || !currentMain) throw new Error("The game response was incomplete.");

      currentMain.classList.add("leaving");
      await new Promise((resolve) => setTimeout(resolve, 180));
      currentMain.innerHTML = nextMain.innerHTML;
      currentMain.dataset.scene = nextMain.dataset.scene;
      currentMain.dataset.action = nextMain.dataset.action;
      currentMain.dataset.ending = nextMain.dataset.ending;
      document.title = nextDocument.title;
      currentMain.classList.remove("leaving");
      currentMain.classList.add("arriving");
      currentMain.querySelector("h1")?.focus({ preventScroll: true });
      setTimeout(() => currentMain.classList.remove("arriving"), 900);
    } catch (error) {
      console.error("Could not change game scene:", error);
      const status = document.getElementById("web-error");
      status.textContent = "The game could not complete that action. Check that the local server is still running, then try again.";
      status.hidden = false;
      button.disabled = false;
    }
  });
})();
