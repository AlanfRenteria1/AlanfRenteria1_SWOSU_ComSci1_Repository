"""Browser game session state and action handling."""

import random
from datetime import datetime

from web.pages import PAGES


def new_session() -> dict[str, str]:
    return {
        "scene": "start",
        "message": "",
        "last_action": "",
        "ending_id": "",
    }


def respond(session: dict[str, str], action: str) -> None:
    scene = session["scene"]
    session["message"] = ""
    allowed_actions = {choice["id"] for choice in PAGES[scene]["choices"]}
    if action not in allowed_actions:
        return
    session["last_action"] = action

    def go(destination: str, message: str = "", ending_id: str = "") -> None:
        session["scene"] = destination
        session["message"] = message
        session["ending_id"] = ending_id

    if scene == "start":
        destinations = {
            "lever": ("lever", ""),
            "squirrel": ("squirrel", ""),
            "explore": ("explore", ""),
            "red_button": ("ending", "You pushed the Giant Red Button.", "red_button"),
            "exit": ("closed", ""),
        }
        destination = destinations.get(action)
        if destination:
            go(*destination)
    elif scene == "explore":
        if action in {"archives", "maintenance", "offices", "nuke", "start"}:
            go("nuke" if action == "nuke" else action)
    elif scene == "lever":
        if action == "pull":
            go("start", "The Temporal Engine roars to life. Reality stabilizes. Probably.")
        elif action == "tap":
            go(
                "start",
                "You tap the lever. A squirrel sighs and takes over the lever. "
                "It does a much better job than you.",
            )
        elif action in {"squirrel", "start"}:
            go(action)
        elif action == "readout":
            go(
                "lever",
                f"Temporal calculation readout: "
                f"{datetime.now():%A, %B %d, %Y at %H:%M:%S}.",
            )
    elif scene == "squirrel":
        if action == "weekday":
            go(
                "start",
                f"You whisper “{datetime.now():%A}.” Correct. "
                "Temporal clearance granted; reality stabilizes.",
            )
        elif action == "training":
            go("start", "You are sent to Temporal Safety Training. Many slides; none explain anything.")
        elif action == "squirrel_help":
            go("start", "The squirrels take over the lever. They do a much better job than you.")
        elif action == "secret":
            go("secret", "The squirrel mentions a secret room: one button makes coffee; the other ends everything.")
        elif action in {"archives", "start"}:
            go(action)
    elif scene == "archives":
        if action == "search":
            documents = [
                "Emergency Nut Storage Procedures",
                "Temporal Engine Warranty: VOID",
                "Rubber Chicken Calibration Manual",
                "Coffee Machine Repair Records",
                "Emergency Reality Glue Instructions",
                "Squirrel Union Contract",
            ]
            go("archives", f"You search a filing cabinet and find: {random.choice(documents)}.")
        elif action == "inspect_beam":
            go("archives", "The beam is labeled NDB-9000. Safety rating: Probably. Do not use while existing.")
        elif action == "use_beam":
            go("start", "The Nondescript Teleporting Beam activates. Your atoms rearrange themselves. TELEPORT COMPLETE.")
        elif action == "cycle":
            cycle_number = random.randint(1, 999999)
            go(
                "archives",
                f"A squirrel unlocks a tiny filing cabinet. "
                f"The Number of the Cycle is {cycle_number:,}.",
            )
        elif action == "explore":
            go("explore")
    elif scene == "maintenance":
        if action == "steam":
            go("steam")
        elif action == "tools":
            tools = [
                "Emergency Temporal Hammer",
                "Squirrel-Sized Wrench",
                "Quantum Plunger",
                "Pipe Encouragement Stick",
            ]
            go("maintenance", f"You pick up a {random.choice(tools)}. You have no idea what it does.")
        elif action == "power":
            go("maintenance", "The power box controls the hallway lights, engine, coffee machine, teleporting beam, and something labeled REALITY. You leave it alone.")
        elif action == "vent":
            go("maintenance", "A tiny squirrel in a maintenance helmet crawls out of the vent and hands you a work order: Stop touching things.")
        elif action == "explore":
            go("explore")
    elif scene == "steam":
        if action == "vapuration":
            go(
                "ending",
                "Every valve opens at once. A cloud of steam fills the room. You have been thoroughly Vapurationed.",
                "vapuration",
            )
        elif action == "inspect_pipes":
            go("steam", "One pipe says STEAM. Another says MORE STEAM. The largest says TOO MUCH STEAM.")
        elif action == "warning":
            go("steam", "The warning label reads: “Surely they don't mean ME.”")
        elif action == "maintenance":
            go("maintenance")
    elif scene == "offices":
        if action == "cubicles":
            items = [
                "a calculator displaying 7",
                "a memo titled PLEASE STOP FEEDING THE VENTS",
                "a rubber duck wearing an employee badge",
                "a binder titled REALITY PATCH NOTES",
            ]
            go("offices", f"You explore the cubicles and find {random.choice(items)}.")
        elif action in {"meeting", "break", "printer", "explore"}:
            go(action)
        elif action == "wall":
            destination = random.choice(("backrooms", "wrong_place"))
            if destination == "backrooms":
                go(
                    "backrooms",
                    "You step through the wall and fall into a different reality.",
                    "backrooms",
                )
            else:
                go("wrong_place", "Your hand passes through a suspicious wall. Reality collision error!")
    elif scene == "meeting":
        if action == "meeting_chair":
            go("meeting", "You sit in the important chair and immediately feel qualified to schedule meetings.")
        elif action == "meeting_board":
            go("meeting", "The whiteboard says: ACTION ITEM: Determine what an action item is.")
        elif action == "offices":
            go("offices")
    elif scene == "break":
        if action == "coffee_machine":
            drinks = ["Coffee", "Decaf Coffee", "Employee Motivation", "Mystery", "Tuesday"]
            go("break", f"The coffee machine selects {random.choice(drinks)}. It is technically drinkable.")
        elif action == "microwave":
            go("break", "You clear the microwave's mysterious 00:01 timer. The office is finally at peace.")
        elif action == "fridge":
            items = [
                "a sandwich labeled DO NOT EAT - STEVE",
                "temporal milk that expired yesterday",
                "a single pickle on a paper plate",
                "a takeout container from another timeline",
            ]
            go("break", f"The refrigerator contains {random.choice(items)}.")
        elif action == "offices":
            go("offices")
    elif scene == "printer":
        messages = {
            "print": "The printer produces three blank pages and one labeled HAHAHA.",
            "paper": "The tray is full of paper. The printer flashes OUT OF PAPER.",
            "toner": "The toner is full. The printer flashes TONER EMPTY.",
            "polite": "You politely ask it to cooperate. It prints a page that says NO.",
        }
        if action in messages:
            go("printer", messages[action])
        elif action == "offices":
            go("offices")
    elif scene == "secret":
        if action == "left_button":
            go(
                "ending",
                "SQUIRREL DOOMSDAY PROTOCOL ACTIVATED. Reality is consumed by squirrels.",
                "squirrel_doomsday",
            )
        elif action == "right_button":
            go("start", "A hatch opens and produces a perfect cup of coffee. Time stabilizes. Probably.")
        elif action == "secret_help":
            go("secret", "The squirrel says: “One ends time. One makes coffee. Good luck.”")
        elif action == "disco":
            go("start", "A disco ball descends. Squirrels begin synchronized dancing.")
        elif action == "explore":
            go("explore")
    elif scene == "nuke":
        if action == "red_wire":
            go("start", "You cut the red wire. The countdown stops. Reality continues.")
        elif action == "blue_wire":
            go("ending", "You cut the blue wire. The failsafe detonates.", "blue_wire")
        elif action == "green_wire":
            go(
                "ending",
                "You cut the green wire. The failsafe detonates in a very dramatic way.",
                "green_wire",
            )
        elif action == "fate":
            succeeds = random.random() < 0.5
            message = (
                "Fate decides the failsafe shuts down."
                if succeeds
                else "Fate decides the device explodes."
            )
            go("start" if succeeds else "ending", message, "" if succeeds else "fate")
    elif scene == "wrong_place":
        if action == "door":
            go("wrong_place", "The door moves away at exactly the same speed. It is clearly doing this on purpose.")
        elif action == "floor":
            go("wrong_place", "The floor makes an error sound. Reality appears mildly embarrassed.")
        elif action == "recover":
            go("offices", "A squirrel radios for help. Reality snaps back into place; you are returned to the Offices.")
    elif scene == "ending":
        if action == "start":
            go("start", "You return to the facility entrance.")
        elif action == "exit":
            go("closed", "You leave the facility. Reality remains mostly intact.")
    elif scene in {"backrooms", "closed"}:
        if action == "start":
            go("start", "You return to the facility entrance.")
