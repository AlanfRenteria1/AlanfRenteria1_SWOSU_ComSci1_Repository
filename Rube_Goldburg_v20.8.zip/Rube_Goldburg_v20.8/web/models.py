"""Types used by the browser game's page and choice data."""

from typing import TypedDict


class PageChoice(TypedDict):
    id: str
    name: str


class Page(TypedDict):
    id: str
    name: str
    description: str
    choices: list[PageChoice]
