"""Browser scene content and named action choices."""

from web.models import Page


PAGES: dict[str, Page] = {
    "start": {
        "id": "start",
        "name": "Temporal Calculation Facility",
        "description": "Welcome to the facility. Reality remains mostly intact. Where do you begin?",
        "choices": [
            {"id": "lever", "name": "Inspect the Primary Lever"},
            {"id": "squirrel", "name": "Talk to the Mechanical Squirrel"},
            {"id": "explore", "name": "Explore the Facility"},
            {"id": "red_button", "name": "Push the Giant Red Button"},
            {"id": "exit", "name": "Leave the facility"},
        ],
    },
    "explore": {
        "id": "explore",
        "name": "Exploration Wing",
        "description": "Several doors lead to places that are probably safe.",
        "choices": [
            {"id": "archives", "name": "Visit the Squirrel Archives"},
            {"id": "maintenance", "name": "Visit the Maintenance Hall"},
            {"id": "offices", "name": "Visit the Offices"},
            {"id": "nuke", "name": "Enter the Nuclear Failsafe Chamber"},
            {"id": "start", "name": "Return to the facility entrance"},
        ],
    },
    "lever": {
        "id": "lever",
        "name": "Primary Lever",
        "description": "The lever hums with temporal energy. A plaque reads: WARNING: Lever may cause time implosions.",
        "choices": [
            {"id": "pull", "name": "Pull the lever"},
            {"id": "tap", "name": "Tap the lever"},
            {"id": "squirrel", "name": "Ask the squirrel for help"},
            {"id": "readout", "name": "Inspect the Temporal Calculation Readout"},
            {"id": "start", "name": "Step away from the lever"},
        ],
    },
    "squirrel": {
        "id": "squirrel",
        "name": "Mechanical Squirrel",
        "description": "The Mechanical Squirrel looks at you. “Clearance code?” it chitters.",
        "choices": [
            {"id": "weekday", "name": "Say today's weekday"},
            {"id": "training", "name": "Admit you have no clearance"},
            {"id": "squirrel_help", "name": "Offer a rubber chicken"},
            {"id": "secret", "name": "Ask about secret rooms"},
            {"id": "archives", "name": "Ask about the Squirrel Archives"},
            {"id": "start", "name": "Leave the squirrel alone"},
        ],
    },
    "archives": {
        "id": "archives",
        "name": "Squirrel Archives",
        "description": "Thousands of tiny filing cabinets cover the walls. Something large hums behind a pile of boxes.",
        "choices": [
            {"id": "search", "name": "Search the archives"},
            {"id": "inspect_beam", "name": "Inspect the humming machine"},
            {"id": "use_beam", "name": "Use the humming machine"},
            {"id": "cycle", "name": "Find the Number of the Cycle"},
            {"id": "explore", "name": "Leave the archives"},
        ],
    },
    "maintenance": {
        "id": "maintenance",
        "name": "Maintenance Hall",
        "description": "Pipes, wires, gauges, and questionable machinery cover every wall. A loud metallic CLANK echoes above you.",
        "choices": [
            {"id": "steam", "name": "Inspect the Steam Pipes"},
            {"id": "tools", "name": "Inspect the Tool Wall"},
            {"id": "power", "name": "Inspect the Power Box"},
            {"id": "vent", "name": "Inspect the Maintenance Vent"},
            {"id": "explore", "name": "Return to the Exploration Wing"},
        ],
    },
    "steam": {
        "id": "steam",
        "name": "Steam Pipe Control Area",
        "description": "A maze of pipes covers the wall. A large yellow button is labeled VAPURATION.",
        "choices": [
            {"id": "vapuration", "name": "Press VAPURATION"},
            {"id": "inspect_pipes", "name": "Inspect the pipes"},
            {"id": "warning", "name": "Read the warning label"},
            {"id": "maintenance", "name": "Back away"},
        ],
    },
    "offices": {
        "id": "offices",
        "name": "Offices",
        "description": "Rows of gray cubicles stretch across the room. A meeting area and employee wellness break area are nearby.",
        "choices": [
            {"id": "cubicles", "name": "Explore the cubicles"},
            {"id": "meeting", "name": "Visit the meeting area"},
            {"id": "break", "name": "Visit the break area"},
            {"id": "wall", "name": "Inspect a strange part of the wall"},
            {"id": "printer", "name": "Interact with the printer"},
            {"id": "explore", "name": "Return to the Exploration Wing"},
        ],
    },
    "meeting": {
        "id": "meeting",
        "name": "Meeting Area",
        "description": "A long table is surrounded by identical chairs. The whiteboard says: “ACTION ITEM: Determine what an action item is.”",
        "choices": [
            {"id": "meeting_chair", "name": "Sit in the important chair"},
            {"id": "meeting_board", "name": "Inspect the whiteboard"},
            {"id": "offices", "name": "Return to the offices"},
        ],
    },
    "break": {
        "id": "break",
        "name": "Office Break Area",
        "description": "Two coffee machines, a microwave, and a refrigerator occupy the wellness zone.",
        "choices": [
            {"id": "coffee_machine", "name": "Use the coffee machine"},
            {"id": "microwave", "name": "Inspect the microwave"},
            {"id": "fridge", "name": "Open the refrigerator"},
            {"id": "offices", "name": "Return to the offices"},
        ],
    },
    "printer": {
        "id": "printer",
        "name": "Printer Menu",
        "description": "The printer vibrates slightly, as if preparing to be difficult.",
        "choices": [
            {"id": "print", "name": "Try to print a document"},
            {"id": "paper", "name": "Check the paper tray"},
            {"id": "toner", "name": "Check the toner"},
            {"id": "polite", "name": "Politely ask it to cooperate"},
            {"id": "offices", "name": "Back away"},
        ],
    },
    "secret": {
        "id": "secret",
        "name": "Secret Room",
        "description": "Two enormous red buttons sit on a pedestal. One button ends everything; the other makes coffee.",
        "choices": [
            {"id": "left_button", "name": "Press the left button"},
            {"id": "right_button", "name": "Press the right button"},
            {"id": "secret_help", "name": "Ask the squirrel for help"},
            {"id": "explore", "name": "Leave"},
            {"id": "disco", "name": "Choose the hidden option"},
        ],
    },
    "nuke": {
        "id": "nuke",
        "name": "Nuclear Failsafe Chamber",
        "description": "A suspicious failsafe device starts a countdown. Which wire do you cut?",
        "choices": [
            {"id": "red_wire", "name": "Cut the red wire"},
            {"id": "blue_wire", "name": "Cut the blue wire"},
            {"id": "green_wire", "name": "Cut the green wire"},
            {"id": "fate", "name": "Let fate decide"},
        ],
    },
    "wrong_place": {
        "id": "wrong_place",
        "name": "The Wrong Place",
        "description": "An endless gray void surrounds you. A floating door moves away whenever you approach it.",
        "choices": [
            {"id": "door", "name": "Walk toward the floating door"},
            {"id": "floor", "name": "Touch the strange gray floor"},
            {"id": "recover", "name": "Ask the squirrel for help"},
        ],
    },
    "backrooms": {
        "id": "backrooms",
        "name": "The Backrooms",
        "description": "Endless yellow rooms stretch in every direction. The facility and its teleportation signal are gone. GAME OVER.",
        "choices": [{"id": "start", "name": "Return to the facility"}],
    },
    "ending": {
        "id": "ending",
        "name": "Game Over",
        "description": "Reality has been thoroughly inconvenienced. GAME OVER.",
        "choices": [
            {"id": "start", "name": "Return to the facility"},
            {"id": "exit", "name": "Leave the facility"},
        ],
    },
    "closed": {
        "id": "closed",
        "name": "Facility Closed",
        "description": "You leave the facility. Reality remains… mostly intact.",
        "choices": [{"id": "start", "name": "Start again"}],
    },
}
