"""Distinct browser game-over messages and effects."""


ENDING_DETAILS = {
    "default": (
        "Reality Reset Required",
        "The timeline has reached an unexpected conclusion. Reality needs a reset.",
    ),
    "red_button": (
        "Reality Reset Required",
        "You pushed the Giant Red Button. The facility has filed a complaint with causality.",
    ),
    "vapuration": (
        "Vapuration Complete",
        "Every valve opened at once. The steam won this round.",
    ),
    "squirrel_doomsday": (
        "Squirrel Doomsday",
        "Mechanical squirrels swarm the room. Reality is now under new management.",
    ),
    "blue_wire": (
        "Failsafe Detonated",
        "You cut the blue wire. The failsafe did exactly what the warning said.",
    ),
    "green_wire": (
        "Failsafe Detonated",
        "You cut the green wire. The explosion was, unfortunately, very dramatic.",
    ),
    "fate": (
        "Fate Has Decided",
        "The device explodes in a very bureaucratic manner. The paperwork survives.",
    ),
    "backrooms": (
        "Signal Lost",
        "The facility is gone. The yellow halls continue in every direction.",
    ),
}
