"""Compatibility entry point for the modular browser game."""

from web.config import HOST, PORT, SCENE_ART, WEB_ASSET_DIR, WEB_ASSET_FILES
from web.game import new_session, respond
from web.pages import PAGES
from web.rendering import render_page
from web.server import GameHandler, SESSIONS, SESSIONS_LOCK, run_server


if __name__ == "__main__":
    run_server()
