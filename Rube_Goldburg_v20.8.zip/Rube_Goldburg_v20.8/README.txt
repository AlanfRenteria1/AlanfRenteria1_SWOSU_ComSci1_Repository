Rube_Goldburg_v20.8 — Temporal Calculation Facility

This version keeps the terminal and browser game, with shared terminal
selection/game-over feedback, scene-specific browser artwork, and animated
transitions. Browser scenes, game logic, rendering, and server code are split
into separate modules.

Requirements:
- Python 3
- No third-party packages

Run the browser version:
1. Extract the project ZIP.
2. Open the extracted Rube_Goldburg_v20.8 folder.
3. Double-click run_web.bat, or open PowerShell in this folder and run:
   python web_app.py
4. The game opens at http://127.0.0.1:8000. If it does not open automatically,
   paste that address into your browser.
5. Keep the terminal window open while playing. Press Ctrl+C there to stop.

The original terminal version can still be started with: python main.py

Browser illustrations are stored separately in the Web_Assets folder as SVG
files and are served locally. Browser code is organized under the web folder;
the HTML template and browser styles/scripts are kept in their own folders.
web_app.py remains the browser launch entry point.

The browser version includes animated scene transitions and synthesized sound
effects. The terminal version uses system tones on Windows and the terminal
bell on other platforms.
