"""Individual locations in the Temporal Calculation Facility."""
