"""Game areas."""
