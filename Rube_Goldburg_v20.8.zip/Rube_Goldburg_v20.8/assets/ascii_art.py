# ASCII art constants
from core.constants import BLUE, CYAN, MAGENTA, RED, RESET, YELLOW


TEMPORAL_READOUT_ART = CYAN + """
╔════════════════════════════════════════════╗
║       TEMPORAL CALCULATION READOUT         ║
╠════════════════════════════════════════════╣
""" + RESET

TEMPORAL_READOUT_BOTTOM = CYAN + "╚════════════════════════════════════════════╝" + RESET

SQUIRREL_ARCHIVE_ART_TOP = MAGENTA + """
╔════════════════════════════════════════════╗
║          SQUIRREL ARCHIVE RECORD           ║
╠════════════════════════════════════════════╣
""" + RESET

SQUIRREL_ARCHIVE_ART_BOTTOM = MAGENTA + "╚════════════════════════════════════════════╝" + RESET

TELEPORT_BEAM_ART = MAGENTA + r"""
        ╔══════════════════════════════════╗
        ║                                  ║
        ║    NONDESCRIPT TELEPORTING       ║
        ║            BEAM™                 ║
        ║                                  ║
        ║          ┌─────────┐             ║
        ║          │   ???   │             ║
        ║          │   ⚡    │             ║
        ║          └────┬────┘             ║
        ║               │                  ║
        ║             \ │ /                ║
        ║              \│/                 ║
        ║               ▼                  ║
        ║             [ YOU ]              ║
        ║                                  ║
        ╚══════════════════════════════════╝
""" + RESET

VAPURATION_WARNING_ART = RED + r"""
╔════════════════════════════════════════════╗
║                  WARNING                   ║
╠════════════════════════════════════════════╣
║                                            ║
║   VAPURATION SYSTEM                        ║
║                                            ║
║   DO NOT PRESS WHILE STANDING HERE.        ║
║                                            ║
║   Seriously.                               ║
║                                            ║
║   We put the button somewhere else         ║
║   originally, but nobody could reach it.   ║
║                                            ║
╚════════════════════════════════════════════╝
""" + RESET

STEAM_PIPE_ART = YELLOW + r"""
        ╔══════════════════════════════╗
        ║     STEAM PIPE CONTROL       ║
        ╠══════════════════════════════╣
        ║                              ║
        ║        ┌──────────┐          ║
        ║        │   !!!    │          ║
        ║        │ PRESS ME │          ║
        ║        └──────────┘          ║
        ║                              ║
        ║        VAPURATION            ║
        ║                              ║
        ╚══════════════════════════════╝
""" + RESET

POWER_BOX_ART = BLUE + r"""
╔════════════════════════════════╗
║         POWER CONTROL          ║
╠════════════════════════════════╣
║                                ║
║ [ON]  Hallway Lights           ║
║ [ON]  Temporal Engine          ║
║ [ON]  Squirrel Archives        ║
║ [ON]  Coffee Machine           ║
║ [ON]  Teleporting Beam         ║
║ [???] Reality                  ║
║                                ║
╚════════════════════════════════╝
""" + RESET

MEETING_NOTES_ART = CYAN + r"""
        TEMPORAL ENGINE MEETING NOTES

                  Problem
                     |
                     v
              Schedule Meeting
                     |
                     v
               Discuss Problem
                     |
                     v
           Schedule Another Meeting
                     |
                     v
            Forget Original Problem
                     |
                     v
                  SUCCESS?
""" + RESET

BACKROOMS_ART = YELLOW + r"""
╔══════════════════════════════════════════════════════╗
║                                                      ║
║       │              │              │                ║
║       │              │              │                ║
║───────┘              └──────────────┘                ║
║                                                      ║
║               ┌─────────────┐                        ║
║               │             │                        ║
║        ───────┘             └──────────              ║
║                                                      ║
║    │                      │                          ║
║    │                      │                          ║
║    └────────────          └───────────────           ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
""" + RESET

PRIMARY_LEVER_ART = CYAN + r"""
        ╭────────────────────────────╮
        │     TEMPORAL CONTROL       │
        │                            │
        │          .---.             │
        │         /     \            │
        │        |  LEVER |           │
        │         \  |  /            │
        │          \ | /             │
        │           \|/              │
        │          [___]             │
        ╰────────────────────────────╯
""" + RESET

ARCHIVES_SCENE_ART = MAGENTA + r"""
╭──────────────────────────────────────────────╮
│             SQUIRREL ARCHIVES                │
├──────────────────────────────────────────────┤
│  [ACORNS]  [FILES]  [FILES]  [ACORNS]         │
│  ┌──────┐  ┌──────┐ ┌──────┐  ┌──────┐        │
│  │NUTS  │  │???!  │ │VOID  │  │NUTS  │        │
│  └──────┘  └──────┘ └──────┘  └──────┘        │
│       A tiny filing cabinet rattles...        │
╰──────────────────────────────────────────────╯
""" + RESET

OFFICE_SCENE_ART = BLUE + r"""
╭──────────────────────────────────────────────╮
│                 OFFICE WING                  │
├──────────────────────────────────────────────┤
│  ┌────────┐   ┌────────┐   ┌────────┐         │
│  │  Q?    │   │  7     │   │  DUCK  │         │
│  └───┬────┘   └───┬────┘   └───┬────┘         │
│   ___│___       __│___       __│___           │
│  /_______\     /______\     /______\          │
│       The office is suspiciously quiet.       │
╰──────────────────────────────────────────────╯
""" + RESET

MAINTENANCE_HALL_ART = YELLOW + r"""
╭──────────────────────────────────────────────╮
│                MAINTENANCE                   │
├──────────────────────────────────────────────┤
│  ═══════╗       ┌───────────────┐             │
│         ╚══╗    │  POWER: ???   │             │
│  ┌───────┐ ║    └───────────────┘             │
│  │ STEAM │ ╚═══════╦════════════════         │
│  └───────┘         ║     ▣ VENT               │
│           CLANK... ║                          │
╰──────────────────────────────────────────────╯
""" + RESET

TOOL_WALL_ART = CYAN + r"""
╭──────────────────────────────────────────────╮
│              TOOLS FOR EVERY JOB             │
├──────────────────────────────────────────────┤
│   🔨      ─┐       ( )       ┌──────┐         │
│  HAMMER    │  WRENCH  PLUNGER │ CROWBAR│       │
│   ─┬─      └─       \___/     └──────┘         │
│   Every label is technically unhelpful.       │
╰──────────────────────────────────────────────╯
""" + RESET

VENT_ART = BLUE + r"""
╭──────────────────────────────────╮
│          MAINTENANCE VENT        │
├──────────────────────────────────┤
│     ┌──────────────────────┐     │
│     │  ══════════════════  │     │
│     │  ══════════════════  │     │
│     │       o      o       │     │
│     └──────────────────────┘     │
│       A tiny helmet appears.     │
╰──────────────────────────────────╯
""" + RESET

GAME_OVER_ART = RED + r"""
╔══════════════════════════════════════════════╗
║                                              ║
║   ▄▀▀ █▀█ █▀▄▀█ █▀▀   ▄▀█ █ █ █▀▀ █▀█        ║
║   █▄█ █▄█ █ ▀ █ ██▄   █▀█ ▀▄▀ ██▄ █▀▄        ║
║                                              ║
║            REALITY NEEDS A RESET             ║
╚══════════════════════════════════════════════╝
""" + RESET
