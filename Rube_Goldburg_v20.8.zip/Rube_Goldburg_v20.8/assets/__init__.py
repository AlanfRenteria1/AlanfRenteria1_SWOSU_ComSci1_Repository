"""Terminal illustrations and art assets."""
