"""Shared terminal game utilities and rules."""
