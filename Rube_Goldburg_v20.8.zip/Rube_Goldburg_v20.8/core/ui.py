"""Console text and sound effects shared by the terminal game."""

import sys
import time

from core.constants import CYAN, GREEN, RED, RESET

try:
    import winsound
except ImportError:
    winsound = None


def say(text, delay=0.75):
    """Print a line and preserve the original game's pacing."""
    print(text, flush=True)
    if delay > 0:
        time.sleep(delay)


def say_color(text, color, delay=0.75):
    say(color + text + RESET, delay)


def read_selection(prompt="\nSelection: "):
    """Read an option and show a brief confirmation animation."""
    choice = input(prompt).strip()
    if choice:
        for frame in ("·", "··", "···"):
            sys.stdout.write(f"\r{CYAN}  Processing choice{frame}{RESET}")
            sys.stdout.flush()
            time.sleep(0.035)
        sys.stdout.write(f"\r{GREEN}  ✓ Choice locked in.{RESET}                  \n")
        sys.stdout.flush()
    return choice


def show_game_over(message):
    """Display the shared terminal game-over screen and return to the start."""
    from assets.ascii_art import GAME_OVER_ART

    print(GAME_OVER_ART)
    say_color(f"\n{message}", RED, delay=0)
    input("\nPress ENTER to return to the facility...")
    return "start"


def _play_tone(frequency, duration_ms):
    if winsound is not None:
        winsound.Beep(frequency, duration_ms)
    else:
        sys.stdout.write("\a")
        sys.stdout.flush()
        time.sleep(duration_ms / 1000)


def beep():
    """Play a short confirmation tone."""
    _play_tone(880, 180)


def fast_beep():
    """Play three quick alert tones."""
    for frequency in (880, 1047, 1319):
        _play_tone(frequency, 90)
        time.sleep(0.045)


def sound_alarm():
    """Play a three-pulse rising alarm and print its text equivalent."""
    print(RED + "WEEEOOO WEEEOOO WEEEOOO" + RESET, flush=True)
    for _ in range(3):
        _play_tone(740, 180)
        _play_tone(988, 220)
        time.sleep(0.08)
