# Color codes
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
BLUE = "\033[94m"
RED = "\033[91m"
RESET = "\033[0m"

# Common UI strings
PROMPT_SELECTION = "\nSelection: "
ERROR_CHOICE_2 = RED + "❌ Choose 1 or 2." + RESET
ERROR_CHOICE_3 = RED + "❌ Choose 1, 2, or 3." + RESET
ERROR_CHOICE_4 = RED + "❌ Choose 1, 2, 3, or 4." + RESET
ERROR_CHOICE_5 = RED + "❌ Choose 1, 2, 3, 4, or 5." + RESET

HEADER_ARCHIVES = CYAN + "\nSquirrel Archives\n─────────────────" + RESET
HEADER_MAINTENANCE = CYAN + "\nMaintenance Hall\n────────────────" + RESET
HEADER_BREAK_AREA = CYAN + "\nBreak Area\n──────────" + RESET
HEADER_MEETING = CYAN + "\nMeeting Area\n────────────" + RESET
HEADER_PRINTER = CYAN + "\nPrinter Menu\n────────────" + RESET
HEADER_WRONG_PLACE = MAGENTA + "\nThe Wrong Place\n───────────────" + RESET
