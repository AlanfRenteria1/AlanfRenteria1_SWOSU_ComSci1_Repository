"""Reusable, ID-based menus for the terminal game."""

from typing import Optional, TypedDict

from core.constants import BLUE, CYAN, PROMPT_SELECTION, RESET
from core.ui import read_selection


class MenuOption(TypedDict):
    """A menu choice with a stable ID, display name, and input key."""

    id: str
    name: str
    key: str


def select_option(title: str, options: list[MenuOption]) -> Optional[str]:
    """Display numbered options and return the selected option's ID."""
    print(f"\n{CYAN}╭─ {title}{RESET}")
    for option in options:
        print(f"{BLUE}│ {option['key']}{RESET}  {option['name']}")
    print(f"{CYAN}╰{'─' * (len(title) + 2)}{RESET}")

    choice = read_selection(PROMPT_SELECTION).upper()
    return next(
        (option["id"] for option in options if option["key"] == choice),
        None,
    )
