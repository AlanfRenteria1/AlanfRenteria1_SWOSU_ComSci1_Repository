"""Local browser version of the Temporal Calculation Facility game."""

from __future__ import annotations

import html
import random
import secrets
import threading
import webbrowser
from datetime import datetime
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import TypedDict
from urllib.parse import parse_qs, urlsplit


HOST = "127.0.0.1"
PORT = 8000
SESSIONS: dict[str, dict[str, str]] = {}
SESSIONS_LOCK = threading.Lock()
WEB_ASSET_DIR = Path(__file__).resolve().parent / "Web_Assets"


class PageChoice(TypedDict):
    id: str
    name: str


class Page(TypedDict):
    id: str
    name: str
    description: str
    choices: list[PageChoice]


WEB_ASSET_FILES = {
    "facility.svg": "facility.svg",
    "primary-lever.svg": "primary-lever.svg",
    "mechanical-squirrel.svg": "mechanical-squirrel.svg",
    "teleport-beam.svg": "teleport-beam.svg",
    "backrooms.svg": "backrooms.svg",
    "steam-pipes.svg": "steam-pipes.svg",
}
SCENE_ART = {
    "start": ("facility.svg", "Illustration of the Temporal Calculation Facility"),
    "explore": ("facility.svg", "Illustration of the Temporal Calculation Facility"),
    "lever": ("primary-lever.svg", "Illustration of the Primary Lever and temporal readout"),
    "squirrel": ("mechanical-squirrel.svg", "Illustration of a mechanical squirrel"),
    "archives": ("mechanical-squirrel.svg", "Illustration of the squirrel archives"),
    "maintenance": ("steam-pipes.svg", "Illustration of the Maintenance Hall pipes"),
    "steam": ("steam-pipes.svg", "Illustration of the steam pipe controls"),
    "offices": ("facility.svg", "Illustration of the facility"),
    "meeting": ("facility.svg", "Illustration of the facility"),
    "break": ("facility.svg", "Illustration of the facility"),
    "printer": ("facility.svg", "Illustration of the facility"),
    "secret": ("teleport-beam.svg", "Illustration of a glowing temporal beam"),
    "nuke": ("primary-lever.svg", "Illustration of a temporal control console"),
    "wrong_place": ("backrooms.svg", "Illustration of a distorted maze"),
    "backrooms": ("backrooms.svg", "Illustration of the Backrooms"),
    "ending": ("teleport-beam.svg", "Illustration of a temporal anomaly"),
    "closed": ("facility.svg", "Illustration of the Temporal Calculation Facility"),
}

PAGES: dict[str, Page] = {
    "start": {
        "id": "start",
        "name": "Temporal Calculation Facility",
        "description": "Welcome to the facility. Reality remains mostly intact. Where do you begin?",
        "choices": [
            {"id": "lever", "name": "Inspect the Primary Lever"},
            {"id": "squirrel", "name": "Talk to the Mechanical Squirrel"},
            {"id": "explore", "name": "Explore the Facility"},
            {"id": "red_button", "name": "Push the Giant Red Button"},
            {"id": "exit", "name": "Leave the facility"},
        ],
    },
    "explore": {
        "id": "explore",
        "name": "Exploration Wing",
        "description": "Several doors lead to places that are probably safe.",
        "choices": [
            {"id": "archives", "name": "Visit the Squirrel Archives"},
            {"id": "maintenance", "name": "Visit the Maintenance Hall"},
            {"id": "offices", "name": "Visit the Offices"},
            {"id": "nuke", "name": "Enter the Nuclear Failsafe Chamber"},
            {"id": "start", "name": "Return to the facility entrance"},
        ],
    },
    "lever": {
        "id": "lever",
        "name": "Primary Lever",
        "description": "The lever hums with temporal energy. A plaque reads: WARNING: Lever may cause time implosions.",
        "choices": [
            {"id": "pull", "name": "Pull the lever"},
            {"id": "tap", "name": "Tap the lever"},
            {"id": "squirrel", "name": "Ask the squirrel for help"},
            {"id": "readout", "name": "Inspect the Temporal Calculation Readout"},
            {"id": "start", "name": "Step away from the lever"},
        ],
    },
    "squirrel": {
        "id": "squirrel",
        "name": "Mechanical Squirrel",
        "description": "The Mechanical Squirrel looks at you. “Clearance code?” it chitters.",
        "choices": [
            {"id": "weekday", "name": "Say today's weekday"},
            {"id": "training", "name": "Admit you have no clearance"},
            {"id": "squirrel_help", "name": "Offer a rubber chicken"},
            {"id": "secret", "name": "Ask about secret rooms"},
            {"id": "archives", "name": "Ask about the Squirrel Archives"},
            {"id": "start", "name": "Leave the squirrel alone"},
        ],
    },
    "archives": {
        "id": "archives",
        "name": "Squirrel Archives",
        "description": "Thousands of tiny filing cabinets cover the walls. Something large hums behind a pile of boxes.",
        "choices": [
            {"id": "search", "name": "Search the archives"},
            {"id": "inspect_beam", "name": "Inspect the humming machine"},
            {"id": "use_beam", "name": "Use the humming machine"},
            {"id": "cycle", "name": "Find the Number of the Cycle"},
            {"id": "explore", "name": "Leave the archives"},
        ],
    },
    "maintenance": {
        "id": "maintenance",
        "name": "Maintenance Hall",
        "description": "Pipes, wires, gauges, and questionable machinery cover every wall. A loud metallic CLANK echoes above you.",
        "choices": [
            {"id": "steam", "name": "Inspect the Steam Pipes"},
            {"id": "tools", "name": "Inspect the Tool Wall"},
            {"id": "power", "name": "Inspect the Power Box"},
            {"id": "vent", "name": "Inspect the Maintenance Vent"},
            {"id": "explore", "name": "Return to the Exploration Wing"},
        ],
    },
    "steam": {
        "id": "steam",
        "name": "Steam Pipe Control Area",
        "description": "A maze of pipes covers the wall. A large yellow button is labeled VAPURATION.",
        "choices": [
            {"id": "vapuration", "name": "Press VAPURATION"},
            {"id": "inspect_pipes", "name": "Inspect the pipes"},
            {"id": "warning", "name": "Read the warning label"},
            {"id": "maintenance", "name": "Back away"},
        ],
    },
    "offices": {
        "id": "offices",
        "name": "Offices",
        "description": "Rows of gray cubicles stretch across the room. A meeting area and employee wellness break area are nearby.",
        "choices": [
            {"id": "cubicles", "name": "Explore the cubicles"},
            {"id": "meeting", "name": "Visit the meeting area"},
            {"id": "break", "name": "Visit the break area"},
            {"id": "wall", "name": "Inspect a strange part of the wall"},
            {"id": "printer", "name": "Interact with the printer"},
            {"id": "explore", "name": "Return to the Exploration Wing"},
        ],
    },
    "meeting": {
        "id": "meeting",
        "name": "Meeting Area",
        "description": "A long table is surrounded by identical chairs. The whiteboard says: “ACTION ITEM: Determine what an action item is.”",
        "choices": [
            {"id": "meeting_chair", "name": "Sit in the important chair"},
            {"id": "meeting_board", "name": "Inspect the whiteboard"},
            {"id": "offices", "name": "Return to the offices"},
        ],
    },
    "break": {
        "id": "break",
        "name": "Office Break Area",
        "description": "Two coffee machines, a microwave, and a refrigerator occupy the wellness zone.",
        "choices": [
            {"id": "coffee_machine", "name": "Use the coffee machine"},
            {"id": "microwave", "name": "Inspect the microwave"},
            {"id": "fridge", "name": "Open the refrigerator"},
            {"id": "offices", "name": "Return to the offices"},
        ],
    },
    "printer": {
        "id": "printer",
        "name": "Printer Menu",
        "description": "The printer vibrates slightly, as if preparing to be difficult.",
        "choices": [
            {"id": "print", "name": "Try to print a document"},
            {"id": "paper", "name": "Check the paper tray"},
            {"id": "toner", "name": "Check the toner"},
            {"id": "polite", "name": "Politely ask it to cooperate"},
            {"id": "offices", "name": "Back away"},
        ],
    },
    "secret": {
        "id": "secret",
        "name": "Secret Room",
        "description": "Two enormous red buttons sit on a pedestal. One button ends everything; the other makes coffee.",
        "choices": [
            {"id": "left_button", "name": "Press the left button"},
            {"id": "right_button", "name": "Press the right button"},
            {"id": "secret_help", "name": "Ask the squirrel for help"},
            {"id": "explore", "name": "Leave"},
            {"id": "disco", "name": "Choose the hidden option"},
        ],
    },
    "nuke": {
        "id": "nuke",
        "name": "Nuclear Failsafe Chamber",
        "description": "A suspicious failsafe device starts a countdown. Which wire do you cut?",
        "choices": [
            {"id": "red_wire", "name": "Cut the red wire"},
            {"id": "blue_wire", "name": "Cut the blue wire"},
            {"id": "green_wire", "name": "Cut the green wire"},
            {"id": "fate", "name": "Let fate decide"},
        ],
    },
    "wrong_place": {
        "id": "wrong_place",
        "name": "The Wrong Place",
        "description": "An endless gray void surrounds you. A floating door moves away whenever you approach it.",
        "choices": [
            {"id": "door", "name": "Walk toward the floating door"},
            {"id": "floor", "name": "Touch the strange gray floor"},
            {"id": "recover", "name": "Ask the squirrel for help"},
        ],
    },
    "backrooms": {
        "id": "backrooms",
        "name": "The Backrooms",
        "description": "Endless yellow rooms stretch in every direction. The facility and its teleportation signal are gone. GAME OVER.",
        "choices": [{"id": "start", "name": "Return to the facility"}],
    },
    "ending": {
        "id": "ending",
        "name": "Game Over",
        "description": "Reality has been thoroughly inconvenienced. GAME OVER.",
        "choices": [
            {"id": "start", "name": "Return to the facility"},
            {"id": "exit", "name": "Leave the facility"},
        ],
    },
    "closed": {
        "id": "closed",
        "name": "Facility Closed",
        "description": "You leave the facility. Reality remains… mostly intact.",
        "choices": [{"id": "start", "name": "Start again"}],
    },
}


def new_session() -> dict[str, str]:
    return {"scene": "start", "message": ""}


def respond(session: dict[str, str], action: str) -> None:
    scene = session["scene"]
    session["message"] = ""
    allowed_actions = {choice["id"] for choice in PAGES[scene]["choices"]}
    if action not in allowed_actions:
        return

    def go(destination: str, message: str = "") -> None:
        session["scene"] = destination
        session["message"] = message

    if scene == "start":
        destinations = {
            "lever": ("lever", ""),
            "squirrel": ("squirrel", ""),
            "explore": ("explore", ""),
            "red_button": ("ending", "You pushed the Giant Red Button."),
            "exit": ("closed", ""),
        }
        destination = destinations.get(action)
        if destination:
            go(*destination)
    elif scene == "explore":
        if action in {"archives", "maintenance", "offices", "nuke", "start"}:
            go("nuke" if action == "nuke" else action)
    elif scene == "lever":
        if action == "pull":
            go("start", "The Temporal Engine roars to life. Reality stabilizes. Probably.")
        elif action == "tap":
            go("start", "You tap the lever. A squirrel sighs and takes over the lever. It does a much better job than you.")
        elif action in {"squirrel", "start"}:
            go(action)
        elif action == "readout":
            go("lever", f"Temporal calculation readout: {datetime.now():%A, %B %d, %Y at %H:%M:%S}.")
    elif scene == "squirrel":
        if action == "weekday":
            go("start", f"You whisper “{datetime.now():%A}.” Correct. Temporal clearance granted; reality stabilizes.")
        elif action == "training":
            go("start", "You are sent to Temporal Safety Training. Many slides; none explain anything.")
        elif action == "squirrel_help":
            go("start", "The squirrels take over the lever. They do a much better job than you.")
        elif action == "secret":
            go("secret", "The squirrel mentions a secret room: one button makes coffee; the other ends everything.")
        elif action in {"archives", "start"}:
            go(action)
    elif scene == "archives":
        if action == "search":
            documents = ["Emergency Nut Storage Procedures", "Temporal Engine Warranty: VOID", "Rubber Chicken Calibration Manual", "Coffee Machine Repair Records", "Emergency Reality Glue Instructions", "Squirrel Union Contract"]
            go("archives", f"You search a filing cabinet and find: {random.choice(documents)}.")
        elif action == "inspect_beam":
            go("archives", "The beam is labeled NDB-9000. Safety rating: Probably. Do not use while existing.")
        elif action == "use_beam":
            go("start", "The Nondescript Teleporting Beam activates. Your atoms rearrange themselves. TELEPORT COMPLETE.")
        elif action == "cycle":
            go("archives", f"A squirrel unlocks a tiny filing cabinet. The Number of the Cycle is {random.randint(1, 999999):,}.")
        elif action == "explore":
            go("explore")
    elif scene == "maintenance":
        if action == "steam":
            go("steam")
        elif action == "tools":
            go("maintenance", f"You pick up a {random.choice(['Emergency Temporal Hammer', 'Squirrel-Sized Wrench', 'Quantum Plunger', 'Pipe Encouragement Stick'])}. You have no idea what it does.")
        elif action == "power":
            go("maintenance", "The power box controls the hallway lights, engine, coffee machine, teleporting beam, and something labeled REALITY. You leave it alone.")
        elif action == "vent":
            go("maintenance", "A tiny squirrel in a maintenance helmet crawls out of the vent and hands you a work order: Stop touching things.")
        elif action == "explore":
            go("explore")
    elif scene == "steam":
        if action == "vapuration":
            go("ending", "Every valve opens at once. A cloud of steam fills the room. You have been thoroughly Vapurationed.")
        elif action == "inspect_pipes":
            go("steam", "One pipe says STEAM. Another says MORE STEAM. The largest says TOO MUCH STEAM.")
        elif action == "warning":
            go("steam", "The warning label reads: “Surely they don't mean ME.”")
        elif action == "maintenance":
            go("maintenance")
    elif scene == "offices":
        if action == "cubicles":
            go("offices", f"You explore the cubicles and find {random.choice(['a calculator displaying 7', 'a memo titled PLEASE STOP FEEDING THE VENTS', 'a rubber duck wearing an employee badge', 'a binder titled REALITY PATCH NOTES'])}.")
        elif action in {"meeting", "break", "printer", "explore"}:
            go(action)
        elif action == "wall":
            go("wrong_place", "Your hand passes through a suspicious wall. Reality collision error!")
    elif scene == "meeting":
        if action == "meeting_chair":
            go("meeting", "You sit in the important chair and immediately feel qualified to schedule meetings.")
        elif action == "meeting_board":
            go("meeting", "The whiteboard says: ACTION ITEM: Determine what an action item is.")
        elif action == "offices":
            go("offices")
    elif scene == "break":
        if action == "coffee_machine":
            go("break", f"The coffee machine selects {random.choice(['Coffee', 'Decaf Coffee', 'Employee Motivation', 'Mystery', 'Tuesday'])}. It is technically drinkable.")
        elif action == "microwave":
            go("break", "You clear the microwave's mysterious 00:01 timer. The office is finally at peace.")
        elif action == "fridge":
            go("break", f"The refrigerator contains {random.choice(['a sandwich labeled DO NOT EAT - STEVE', 'temporal milk that expired yesterday', 'a single pickle on a paper plate', 'a takeout container from another timeline'])}.")
        elif action == "offices":
            go("offices")
    elif scene == "printer":
        messages = {
            "print": "The printer produces three blank pages and one labeled HAHAHA.",
            "paper": "The tray is full of paper. The printer flashes OUT OF PAPER.",
            "toner": "The toner is full. The printer flashes TONER EMPTY.",
            "polite": "You politely ask it to cooperate. It prints a page that says NO.",
        }
        if action in messages:
            go("printer", messages[action])
        elif action == "offices":
            go("offices")
    elif scene == "secret":
        if action == "left_button":
            go("ending", "SQUIRREL DOOMSDAY PROTOCOL ACTIVATED. Reality is consumed by squirrels.")
        elif action == "right_button":
            go("start", "A hatch opens and produces a perfect cup of coffee. Time stabilizes. Probably.")
        elif action == "secret_help":
            go("secret", "The squirrel says: “One ends time. One makes coffee. Good luck.”")
        elif action == "disco":
            go("start", "A disco ball descends. Squirrels begin synchronized dancing.")
        elif action == "explore":
            go("explore")
    elif scene == "nuke":
        if action == "red_wire":
            go("start", "You cut the red wire. The countdown stops. Reality continues.")
        elif action == "blue_wire":
            go("ending", "You cut the blue wire. The failsafe detonates.")
        elif action == "green_wire":
            go("ending", "You cut the green wire. The failsafe detonates in a very dramatic way.")
        elif action == "fate":
            succeeds = random.random() < 0.5
            go("start" if succeeds else "ending", "Fate decides the failsafe shuts down." if succeeds else "Fate decides the device explodes.")
    elif scene == "wrong_place":
        if action == "door":
            go("wrong_place", "The door moves away at exactly the same speed. It is clearly doing this on purpose.")
        elif action == "floor":
            go("wrong_place", "The floor makes an error sound. Reality appears mildly embarrassed.")
        elif action == "recover":
            go("offices", "A squirrel radios for help. Reality snaps back into place; you are returned to the Offices.")
    elif scene in {"backrooms", "ending", "closed"}:
        if action == "start":
            go("start", "You return to the facility entrance.")


def render_page(session: dict[str, str]) -> bytes:
    page = PAGES[session["scene"]]
    message = session.get("message", "")
    image_name, image_description = SCENE_ART[session["scene"]]
    safe_title = html.escape(page["name"])
    safe_description = html.escape(page["description"])
    safe_message = html.escape(message)
    safe_image_description = html.escape(image_description, quote=True)
    illustration = (
        f'<img class="illustration" src="/Web_Assets/{image_name}" '
        f'alt="{safe_image_description}">'
    )
    buttons = "".join(
        '<button type="submit" name="action" value="{}">{}</button>'.format(
            html.escape(choice["id"], quote=True), html.escape(choice["name"])
        )
        for choice in page["choices"]
    )
    document = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#101522">
  <title>{safe_title} | Temporal Calculation Facility</title>
  <style>
    :root {{ color-scheme: dark; font-family: system-ui, sans-serif; background: #101522; color: #edf2ff; }}
    body {{ margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 1.25rem; box-sizing: border-box; }}
    main {{ width: min(100%, 44rem); background: #1b2435; border: 1px solid #36445f; border-radius: 1rem; padding: clamp(1.25rem, 5vw, 2.5rem); box-shadow: 0 1.5rem 5rem #0006; opacity: 1; transform: translateY(0) scale(1); transition: opacity .2s ease, transform .2s ease; }}
    main.leaving {{ opacity: 0; transform: translateY(12px) scale(.985); }}
    main.arriving {{ animation: arrive .48s cubic-bezier(.2,.8,.2,1) both; }}
    @keyframes arrive {{ from {{ opacity: 0; transform: translateY(-14px) scale(.985); filter: blur(4px); }} to {{ opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }} }}
    h1 {{ margin-top: 0; color: #ffe083; font-size: clamp(1.6rem, 5vw, 2.2rem); }}
    h1, main > p {{ animation: text-in .42s .06s both; }}
    @keyframes text-in {{ from {{ opacity: 0; transform: translateY(7px); }} to {{ opacity: 1; transform: translateY(0); }} }}
    p {{ line-height: 1.65; }}
    .message {{ border-left: .25rem solid #79d4c4; padding: .6rem 1rem; background: #152e34; border-radius: .25rem; }}
    .illustration {{ display: block; width: 100%; aspect-ratio: 8 / 3; object-fit: cover; border: 1px solid #526586; border-radius: .75rem; margin: 1.25rem 0; animation: art-in .6s .04s both; }}
    @keyframes art-in {{ from {{ opacity: .35; transform: scale(.97); }} to {{ opacity: 1; transform: scale(1); }} }}
    form {{ display: grid; gap: .75rem; margin-top: 1.5rem; }}
    button {{ appearance: none; border: 1px solid #526586; border-radius: .6rem; padding: .9rem 1rem; background: #263650; color: inherit; text-align: left; font: inherit; cursor: pointer; transition: background .16s ease, border-color .16s ease, transform .16s ease; }}
    button:hover, button:focus-visible {{ background: #385175; border-color: #ffe083; transform: translateX(4px); outline: 2px solid transparent; }}
    button:disabled {{ opacity: .6; cursor: wait; }}
    .error {{ color: #ffaaa6; }}
    footer {{ margin-top: 1.5rem; color: #aab8cf; font-size: .85rem; }}
    @media (prefers-reduced-motion: reduce) {{ *, *::before, *::after {{ animation-duration: .01ms !important; animation-iteration-count: 1 !important; scroll-behavior: auto !important; transition-duration: .01ms !important; }} }}
  </style>
</head>
<body>
  <main data-scene="{page['id']}">
    <h1 tabindex="-1">{safe_title}</h1>
    <p>{safe_description}</p>
    {illustration}
    {f'<p class="message" role="status">{safe_message}</p>' if safe_message else ''}
    <form method="post" action="/action">{buttons}</form>
    <p id="web-error" class="error" role="alert" hidden></p>
    <footer>Running locally on this computer</footer>
  </main>
  <script>
    (() => {{
      let audioContext;
      const cues = {{
        pull: [660, 880, 1175], tap: [440, 392], use_beam: [440, 660, 880, 1320],
        vapuration: [220, 330, 220], red_wire: [880, 1175], blue_wire: [220, 165],
        green_wire: [220, 165], fate: [523, 784], print: [600, 440, 600],
        search: [740, 988], squirrel: [660, 880], red_button: [180, 130]
      }};
      function playSound(action) {{
        const AudioContextType = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextType) return;
        try {{
          audioContext ||= new AudioContextType();
          if (audioContext.state === "suspended") {{
            audioContext.resume().catch((error) => console.warn("Audio could not resume:", error));
          }}
          const notes = cues[action] || [520, 690];
          notes.forEach((frequency, index) => {{
            const start = audioContext.currentTime + index * .085;
            const oscillator = audioContext.createOscillator();
            const gain = audioContext.createGain();
            oscillator.type = action === "vapuration" || action === "red_button" ? "sawtooth" : "sine";
            oscillator.frequency.setValueAtTime(frequency, start);
            gain.gain.setValueAtTime(.0001, start);
            gain.gain.exponentialRampToValueAtTime(.055, start + .012);
            gain.gain.exponentialRampToValueAtTime(.0001, start + .12);
            oscillator.connect(gain);
            gain.connect(audioContext.destination);
            oscillator.start(start);
            oscillator.stop(start + .13);
          }});
        }} catch (error) {{
          console.warn("Sound effects could not be played:", error);
        }}
      }}
      document.addEventListener("submit", async (event) => {{
        const form = event.target;
        if (!(form instanceof HTMLFormElement) || form.action !== location.origin + "/action") return;
        event.preventDefault();
        const button = event.submitter;
        if (!(button instanceof HTMLButtonElement)) return;
        button.disabled = true;
        playSound(button.value);
        const payload = new URLSearchParams({{ action: button.value }});
        try {{
          const response = await fetch(form.action, {{
            method: "POST",
            headers: {{ "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" }},
            body: payload
          }});
          if (!response.ok) throw new Error(`Server returned ${{response.status}}`);
          const nextDocument = new DOMParser().parseFromString(await response.text(), "text/html");
          const nextMain = nextDocument.querySelector("main");
          const currentMain = document.querySelector("main");
          if (!nextMain || !currentMain) throw new Error("The game response was incomplete.");
          currentMain.classList.add("leaving");
          await new Promise((resolve) => setTimeout(resolve, 180));
          currentMain.innerHTML = nextMain.innerHTML;
          currentMain.dataset.scene = nextMain.dataset.scene;
          document.title = nextDocument.title;
          currentMain.classList.remove("leaving");
          currentMain.classList.add("arriving");
          currentMain.querySelector("h1")?.focus({{ preventScroll: true }});
          setTimeout(() => currentMain.classList.remove("arriving"), 550);
        }} catch (error) {{
          console.error("Could not change game scene:", error);
          const status = document.getElementById("web-error");
          status.textContent = "The game could not complete that action. Check that the local server is still running, then try again.";
          status.hidden = false;
          button.disabled = false;
        }}
      }});
    }})();
  </script>
</body>
</html>"""
    return document.encode("utf-8")


class GameHandler(BaseHTTPRequestHandler):
    server_version = "TemporalFacility/1.0"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def session(self) -> tuple[str, dict[str, str], bool]:
        cookie = cookies.SimpleCookie(self.headers.get("Cookie"))
        morsel = cookie.get("facility_session")
        session_id = morsel.value if morsel else ""
        if session_id:
            with SESSIONS_LOCK:
                session = SESSIONS.get(session_id)
                if session is not None:
                    return session_id, session, False
        session_id = secrets.token_urlsafe(24)
        session = new_session()
        with SESSIONS_LOCK:
            SESSIONS[session_id] = session
        return session_id, session, True

    def send_page(self, session_id: str, session: dict[str, str], set_cookie: bool) -> None:
        body = render_page(session)
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if set_cookie:
            self.send_header(
                "Set-Cookie",
                f"facility_session={session_id}; HttpOnly; SameSite=Lax; Path=/",
            )
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        request_path = urlsplit(self.path).path
        if request_path.startswith("/Web_Assets/"):
            asset_name = request_path.removeprefix("/Web_Assets/")
            filename = WEB_ASSET_FILES.get(asset_name)
            if filename is None:
                self.send_error(404)
                return
            try:
                body = (WEB_ASSET_DIR / filename).read_bytes()
            except OSError:
                self.send_error(500, "Web illustration could not be loaded")
                return
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "public, max-age=3600")
            self.end_headers()
            self.wfile.write(body)
            return
        if request_path not in {"/", "/index.html"}:
            self.send_error(404)
            return
        session_id, session, set_cookie = self.session()
        self.send_page(session_id, session, set_cookie)

    def do_POST(self) -> None:
        if self.path != "/action":
            self.send_error(404)
            return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_error(400, "Invalid form submission")
            return
        if content_length < 0 or content_length > 4096:
            self.send_error(413, "Form submission is too large")
            return
        body = self.rfile.read(content_length).decode("utf-8", errors="replace")
        values = parse_qs(body, keep_blank_values=False).get("action", [])
        if not values:
            self.send_error(400, "Missing action")
            return
        session_id, session, set_cookie = self.session()
        with SESSIONS_LOCK:
            respond(session, values[0])
            self.send_page(session_id, session, set_cookie)


def run_server() -> None:
    server = ThreadingHTTPServer((HOST, PORT), GameHandler)
    url = f"http://{HOST}:{PORT}/"
    print(f"Temporal Calculation Facility is running at {url}")
    print("Press Ctrl+C to stop the server.")
    try:
        webbrowser.open(url)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    run_server()
