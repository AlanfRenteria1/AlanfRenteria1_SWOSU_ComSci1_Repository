"""Reusable, ID-based menus for the terminal game."""

from typing import Optional, TypedDict

from core.constants import PROMPT_SELECTION


class MenuOption(TypedDict):
    """A menu choice with a stable ID, display name, and input key."""

    id: str
    name: str
    key: str


def select_option(title: str, options: list[MenuOption]) -> Optional[str]:
    """Display numbered options and return the selected option's ID."""
    print(f"\n{title}")
    for option in options:
        print(f"{option['key']} - {option['name']}")

    choice = input(PROMPT_SELECTION).strip().upper()
    return next(
        (option["id"] for option in options if option["key"] == choice),
        None,
    )
