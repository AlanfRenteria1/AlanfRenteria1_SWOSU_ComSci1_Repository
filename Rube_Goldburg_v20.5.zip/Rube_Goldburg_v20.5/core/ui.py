"""Console text and sound effects shared by the terminal game."""

import sys
import time

from core.constants import RED, RESET

try:
    import winsound
except ImportError:
    winsound = None


def say(text, delay=0.75):
    """Print a line and preserve the original game's pacing."""
    print(text, flush=True)
    if delay > 0:
        time.sleep(delay)


def say_color(text, color, delay=0.75):
    say(color + text + RESET, delay)


def _play_tone(frequency, duration_ms):
    if winsound is not None:
        winsound.Beep(frequency, duration_ms)
    else:
        sys.stdout.write("\a")
        sys.stdout.flush()
        time.sleep(duration_ms / 1000)


def beep():
    """Play a short confirmation tone."""
    _play_tone(880, 180)


def fast_beep():
    """Play three quick alert tones."""
    for frequency in (880, 1047, 1319):
        _play_tone(frequency, 90)
        time.sleep(0.045)


def sound_alarm():
    """Play a three-pulse rising alarm and print its text equivalent."""
    print(RED + "WEEEOOO WEEEOOO WEEEOOO" + RESET, flush=True)
    for _ in range(3):
        _play_tone(740, 180)
        _play_tone(988, 220)
        time.sleep(0.08)
