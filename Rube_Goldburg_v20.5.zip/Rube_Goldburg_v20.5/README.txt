Rube_Goldburg_v20.5 — Temporal Calculation Facility

This version organizes terminal menu choices and browser page choices as
named records with stable IDs, making the game flow easier to read and update.
Both launch options remain available.

Requirements:
- Python 3
- No third-party packages

Run the browser version:
1. Extract the project ZIP.
2. Open the extracted Rube_Goldburg_v20.4 folder.
3. Double-click run_web.bat, or open PowerShell in this folder and run:
   python web_app.py
4. The game opens at http://127.0.0.1:8000. If it does not open automatically,
   paste that address into your browser.
5. Keep the terminal window open while playing. Press Ctrl+C there to stop.

The original terminal version can still be started with: python main.py

Browser illustrations are stored separately in the Web_Assets folder as SVG
files and are served locally by web_app.py. The browser version includes
animated scene transitions and synthesized sound effects. The terminal version
uses system tones on Windows and the terminal bell on other platforms.
