@echo off
cd /d "%~dp0"
python web_app.py
if errorlevel 1 (
    echo.
    echo Could not start the web game. Make sure Python is installed and on PATH.
    pause
)
