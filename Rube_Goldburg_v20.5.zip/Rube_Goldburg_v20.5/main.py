import sys
from collections.abc import Callable

from core.constants import ERROR_CHOICE_5, RED, RESET, YELLOW
from core.game_logic import game_over
from core.menus import MenuOption, select_option
from core.ui import say, say_color
from core.utilities import clear_screen

from areas.areas.archives import visit_archives
from areas.areas.maintenance import visit_maintenance
from areas.areas.offices import visit_offices
from areas.areas.squirrel import talk_to_squirrel
from areas.areas.lever import pull_lever

from areas.areas.special_rooms import enter_secret_room
from areas.areas.Nuke_Room import enter_nuke_room

from areas.areas.glitch_spaces import (
    visit_wrong_place,
    enter_backrooms
)


START_MENU: list[MenuOption] = [
    {"id": "lever", "name": "Inspect the Primary Lever", "key": "1"},
    {"id": "squirrel", "name": "Talk to the Mechanical Squirrel", "key": "2"},
    {"id": "explore", "name": "Explore the Facility", "key": "3"},
    {"id": "red_button", "name": "Push the Giant Red Button", "key": "4"},
    {"id": "exit", "name": "Exit the facility", "key": "E"},
]

EXPLORE_MENU: list[MenuOption] = [
    {"id": "archives", "name": "Visit the Squirrel Archives", "key": "1"},
    {"id": "maintenance", "name": "Visit the Maintenance Hall", "key": "2"},
    {"id": "offices", "name": "Visit the Offices", "key": "3"},
    {"id": "nuke_room", "name": "Enter the Nuclear Failsafe Chamber", "key": "4"},
    {"id": "start", "name": "Return to the facility entrance", "key": "5"},
]


def explore():
    while True:
        selected_id = select_option("Exploration Wing", EXPLORE_MENU)
        if selected_id is None:
            print(ERROR_CHOICE_5)
            continue
        return selected_id


def show_squirrel_help():
    say("\nThe squirrels take over the lever.")
    say("They do a much better job than you.")
    return "start"


def show_training():
    say("\nYou are sent to Temporal Safety Training.")
    say("There are many slides.")
    say("None of them explain anything.")
    return "start"


def show_coffee():
    say("\nYou drink the perfect cup of coffee.")
    say("Time stabilizes. Probably.")
    return "start"


def show_disco():
    say("\nA disco ball descends.")
    say("Squirrels begin synchronized dancing.")
    return "start"


def show_nuke_safe():
    say("\nThe failsafe shuts down.")
    say("Reality continues.")
    return "start"


START_ACTIONS: dict[str, Callable[[], str]] = {
    "lever": pull_lever,
    "squirrel": talk_to_squirrel,
    "explore": explore,
}

STATE_HANDLERS: dict[str, Callable[[], str]] = {
    "archives": visit_archives,
    "maintenance": visit_maintenance,
    "offices": visit_offices,
    "secret_room": enter_secret_room,
    "nuke_room": enter_nuke_room,
    "squirrel": talk_to_squirrel,
    "squirrel_help": show_squirrel_help,
    "training": show_training,
    "coffee": show_coffee,
    "disco": show_disco,
    "nuke_safe": show_nuke_safe,
    "wrong_place": visit_wrong_place,
    "backrooms": enter_backrooms,
}


def main():
    sys.stdout.reconfigure(errors="replace")
    clear_screen()
    say_color("Welcome to the Temporal Calculation Facility!", YELLOW)

    state = "start"

    while True:
        if state == "start":
            selected_id = select_option("Where do you begin?", START_MENU)
            if selected_id is None:
                print(ERROR_CHOICE_5)
            elif selected_id == "exit":
                say("\nYou leave the facility. Reality remains… mostly intact.")
                break
            elif selected_id == "red_button":
                game_over("You pushed the Giant Red Button.")
            else:
                state = START_ACTIONS[selected_id]()
            continue

        handler = STATE_HANDLERS.get(state)
        if handler is None:
            print(RED + "❌ Unknown state. Returning to start." + RESET)
            state = "start"
        else:
            state = handler()


if __name__ == "__main__":
    main()
