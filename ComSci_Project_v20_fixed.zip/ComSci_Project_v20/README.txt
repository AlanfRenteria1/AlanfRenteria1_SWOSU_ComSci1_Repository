Temporal Calculation Facility

Requirements:
- Python 3
- No third-party packages

To run:
1. Extract the project ZIP.
2. Open PowerShell or Command Prompt in the extracted ComSci_Project_v20 folder.
3. Run: python main.py

The project is organized into core, assets, and areas/areas modules. Run main.py
from the project root so Python can find those packages.
