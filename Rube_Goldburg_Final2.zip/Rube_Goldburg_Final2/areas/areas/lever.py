import datetime

from assets.ascii_art import (
    TEMPORAL_READOUT_ART,
)

from core.constants import ERROR_CHOICE_5, PROMPT_SELECTION
from core.events import random_event
from core.ui import read_selection, say, say_color, show_ending, sound_effect
from assets.ascii_art import PRIMARY_LEVER_ART


def show_time_and_date():
    now = datetime.datetime.now()
    print(TEMPORAL_READOUT_ART)
    say(f"  Date: {now:%A, %B %d, %Y}")
    say(f"  Time: {now:%H:%M:%S}")


def pull_lever():
    say("\nYou approach the Primary Lever.")
    print(PRIMARY_LEVER_ART)
    say("It hums with temporal energy.")
    say("A plaque reads: WARNING: Lever may cause time implosions.")

    random_event()

    while True:
        print("\nPrimary Lever")
        print("─────────────")
        print("1 - Pull the lever")
        print("2 - Tap the lever")
        print("3 - Ask the squirrel for help")
        print("4 - Inspect the Temporal Calculation Readout")
        print("5 - Step away from the lever")

        choice = read_selection(PROMPT_SELECTION)

        if choice == "1":
            sound_effect("lever")
            say("\nYou yank the lever.")
            say("The Temporal Engine roars to life!")
            return show_ending(
                "REALITY STABILIZED",
                "The Temporal Engine roars to life. Reality stabilizes. Probably.",
                success=True,
            )
        elif choice == "2":
            sound_effect("lever")
            say("\nYou tap the lever.")
            say("It barely moves.")
            say("A squirrel sighs loudly.")
            return "squirrel_help"
        elif choice == "3":
            return "squirrel"
        elif choice == "4":
            sound_effect("readout")
            say("\nA small display flickers to life.")
            show_time_and_date()
        elif choice == "5":
            say("\nYou wisely step away from the suspicious lever.")
            return "start"
        else:
            print(ERROR_CHOICE_5)
