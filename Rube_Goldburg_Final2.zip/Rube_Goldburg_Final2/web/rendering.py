"""Render browser game sessions into the HTML page template."""

import html
from pathlib import Path

from web.config import ACTION_ART, ENDING_ART, SCENE_ART
from web.endings import ENDING_DETAILS, SUCCESS_ENDINGS
from web.models import Page
from web.pages import PAGES


TEMPLATE_PATH = Path(__file__).resolve().parent / "templates" / "page.html"
TEMPLATE = TEMPLATE_PATH.read_text(encoding="utf-8")


def render_page(session: dict[str, str]) -> bytes:
    page: Page = PAGES[session["scene"]]
    scene = session["scene"]
    action = session.get("last_action", "")
    ending_id = session.get("ending_id", "")
    image_name, image_description = ACTION_ART.get(action, SCENE_ART[scene])
    title = page["name"]
    description = page["description"]
    is_outcome_screen = scene in {"ending", "backrooms"}
    is_result = is_outcome_screen or scene == "closed"
    if is_result:
        title, description = ENDING_DETAILS.get(ending_id, ENDING_DETAILS["default"])
    if is_outcome_screen:
        image_name, image_description = ENDING_ART.get(
            ending_id,
            ACTION_ART.get(action, SCENE_ART[scene]),
        )
    message = html.escape(session.get("message", ""))

    ending_type = (
        "ending"
        if ending_id in SUCCESS_ENDINGS
        else "game-over"
        if is_outcome_screen
        else ""
    )
    ending_label = "ENDING" if ending_type == "ending" else "GAME OVER"
    choices_html = "".join(
        '<button type="submit" name="action" value="{}">{}</button>'.format(
            html.escape(choice["id"], quote=True),
            html.escape(choice["name"]),
        )
        for choice in page["choices"]
    )
    choices_form_html = f'<form method="post" action="/action">{choices_html}</form>'
    illustration_html = (
        f'<img class="illustration" src="/Web_Assets/{image_name}" '
        f'alt="{html.escape(image_description, quote=True)}">'
    )
    message_html = f'<p class="message" role="status">{message}</p>' if message else ""
    splash_html = ""
    if is_outcome_screen:
        splash_html = (
            f'<section class="end-splash {ending_type}" aria-live="polite">'
            '<span class="splash-orbit" aria-hidden="true"><span></span></span>'
            f'<p class="splash-label">{ending_label}</p>'
            "</section>"
        )
    elif scene == "closed":
        splash_html = (
            '<section class="end-splash closed" aria-live="polite">'
            '<span class="splash-orbit" aria-hidden="true"><span></span></span>'
            '<p class="splash-label">FACILITY CLOSED</p>'
            "</section>"
        )

    replacements = {
        "{{title}}": html.escape(title),
        "{{description}}": html.escape(description),
        "{{scene_id}}": html.escape(page["id"], quote=True),
        "{{action_id}}": html.escape(action, quote=True),
        "{{ending_id}}": html.escape(ending_id, quote=True),
        "{{ending_type}}": ending_type,
        "{{ending_splash}}": splash_html,
        "{{illustration}}": illustration_html,
        "{{message}}": message_html,
        "{{choices_form}}": choices_form_html,
    }
    document = TEMPLATE
    for placeholder, value in replacements.items():
        document = document.replace(placeholder, value)
    return document.encode("utf-8")
