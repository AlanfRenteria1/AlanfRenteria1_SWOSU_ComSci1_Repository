"""Browser server settings and local asset mappings."""

from pathlib import Path


HOST = "127.0.0.1"
PORT = 8000
PROJECT_ROOT = Path(__file__).resolve().parent.parent
WEB_ASSET_DIR = PROJECT_ROOT / "Web_Assets"
STATIC_DIR = Path(__file__).resolve().parent / "static"

WEB_ASSET_FILES = {
    "facility.svg": "facility.svg",
    "primary-lever.svg": "primary-lever.svg",
    "mechanical-squirrel.svg": "mechanical-squirrel.svg",
    "teleport-beam.svg": "teleport-beam.svg",
    "backrooms.svg": "backrooms.svg",
    "steam-pipes.svg": "steam-pipes.svg",
    "squirrel-archives.svg": "squirrel-archives.svg",
    "office-wing.svg": "office-wing.svg",
    "maintenance-hall.svg": "maintenance-hall.svg",
    "tool-wall.svg": "tool-wall.svg",
    "power-box.svg": "power-box.svg",
    "maintenance-vent.svg": "maintenance-vent.svg",
    "office-meeting.svg": "office-meeting.svg",
    "office-breakroom.svg": "office-breakroom.svg",
    "office-printer.svg": "office-printer.svg",
    "game-over.svg": "game-over.svg",
    "red-button-ending.svg": "red-button-ending.svg",
    "vapuration-ending.svg": "vapuration-ending.svg",
    "squirrel-doomsday.svg": "squirrel-doomsday.svg",
    "failsafe-detonated.svg": "failsafe-detonated.svg",
    "squirrel-disco.svg": "squirrel-disco.svg",
    "return-facility.svg": "return-facility.svg",
    "wrong-place.svg": "wrong-place.svg",
    "nuke-chamber.svg": "nuke-chamber.svg",
    "temporal-readout.svg": "temporal-readout.svg",
}

STATIC_FILES = {
    "style.css": ("styles.css", "text/css; charset=utf-8"),
    "game.js": ("game.js", "text/javascript; charset=utf-8"),
}

SCENE_ART = {
    "start": ("facility.svg", "Illustration of the Temporal Calculation Facility"),
    "explore": ("facility.svg", "Illustration of the Temporal Calculation Facility"),
    "lever": ("primary-lever.svg", "Illustration of the Primary Lever and temporal readout"),
    "squirrel": ("mechanical-squirrel.svg", "Illustration of a mechanical squirrel"),
    "archives": ("squirrel-archives.svg", "Illustration of the squirrel archives"),
    "maintenance": ("maintenance-hall.svg", "Illustration of the Maintenance Hall"),
    "steam": ("steam-pipes.svg", "Illustration of the steam pipe controls"),
    "offices": ("office-wing.svg", "Illustration of the facility offices"),
    "meeting": ("office-meeting.svg", "Illustration of the meeting room"),
    "break": ("office-breakroom.svg", "Illustration of the office break area"),
    "printer": ("office-printer.svg", "Illustration of the office printer"),
    "secret": ("teleport-beam.svg", "Illustration of a glowing temporal beam"),
    "nuke": ("nuke-chamber.svg", "Illustration of the nuclear failsafe chamber"),
    "wrong_place": ("wrong-place.svg", "Illustration of the facility's distorted gray void"),
    "backrooms": ("backrooms.svg", "Illustration of the Backrooms"),
    "ending": ("game-over.svg", "Illustration of a temporal anomaly"),
    "ending_options": ("return-facility.svg", "Illustration of a path back to the facility"),
    "closed": ("facility.svg", "Illustration of the Temporal Calculation Facility"),
}

ACTION_ART = {
    "lever": ("primary-lever.svg", "Illustration of the Primary Lever"),
    "pull": ("primary-lever.svg", "Illustration of the activated Primary Lever"),
    "tap": ("primary-lever.svg", "Illustration of the Primary Lever"),
    "squirrel": ("mechanical-squirrel.svg", "Illustration of the mechanical squirrel"),
    "archives": ("squirrel-archives.svg", "Illustration of the squirrel archives"),
    "maintenance": ("maintenance-hall.svg", "Illustration of the Maintenance Hall"),
    "offices": ("office-wing.svg", "Illustration of the office wing"),
    "nuke": ("nuke-chamber.svg", "Illustration of the failsafe chamber controls"),
    "search": ("squirrel-archives.svg", "Illustration of archive filing cabinets"),
    "inspect_beam": ("teleport-beam.svg", "Illustration of the nondescript teleporting beam"),
    "use_beam": ("teleport-beam.svg", "Illustration of the nondescript teleporting beam"),
    "cycle": ("squirrel-archives.svg", "Illustration of a squirrel archive record"),
    "weekday": ("mechanical-squirrel.svg", "Illustration of the clearance-checking squirrel"),
    "secret": ("teleport-beam.svg", "Illustration of a hidden temporal room"),
    "tools": ("tool-wall.svg", "Illustration of the maintenance tool wall"),
    "power": ("power-box.svg", "Illustration of the Maintenance Power Box"),
    "vent": ("maintenance-vent.svg", "Illustration of a squirrel in the maintenance vent"),
    "steam": ("steam-pipes.svg", "Illustration of the steam pipe controls"),
    "vapuration": ("steam-pipes.svg", "Illustration of the Vapuration controls"),
    "cubicles": ("office-wing.svg", "Illustration of the office cubicles"),
    "meeting": ("office-meeting.svg", "Illustration of the meeting room"),
    "meeting_chair": ("office-meeting.svg", "Illustration of the meeting room"),
    "meeting_board": ("office-meeting.svg", "Illustration of the meeting room flowchart"),
    "break": ("office-breakroom.svg", "Illustration of the office break area"),
    "coffee_machine": ("office-breakroom.svg", "Illustration of the break area coffee machine"),
    "microwave": ("office-breakroom.svg", "Illustration of the break area microwave"),
    "fridge": ("office-breakroom.svg", "Illustration of the office refrigerator"),
    "printer": ("office-printer.svg", "Illustration of the temperamental office printer"),
    "print": ("office-printer.svg", "Illustration of the temperamental office printer"),
    "paper": ("office-printer.svg", "Illustration of the temperamental office printer"),
    "toner": ("office-printer.svg", "Illustration of the temperamental office printer"),
    "polite": ("office-printer.svg", "Illustration of the temperamental office printer"),
    "readout": ("temporal-readout.svg", "Illustration of the Temporal Calculation Readout"),
    "door": ("wrong-place.svg", "Illustration of a floating door in the gray void"),
    "floor": ("wrong-place.svg", "Illustration of the strange gray floor"),
    "recover": ("teleport-beam.svg", "Illustration of the rescue teleportation beam"),
}

ENDING_ART = {
    "red_button": (
        "red-button-ending.svg",
        "Illustration of the giant red button tearing open a temporal rift",
    ),
    "vapuration": (
        "vapuration-ending.svg",
        "Illustration of steam overwhelming the facility after Vapuration",
    ),
    "squirrel_doomsday": (
        "squirrel-doomsday.svg",
        "Illustration of mechanical squirrels overrunning the facility",
    ),
    "blue_wire": (
        "failsafe-detonated.svg",
        "Illustration of the failsafe detonating after the blue wire is cut",
    ),
    "green_wire": (
        "failsafe-detonated.svg",
        "Illustration of the failsafe detonating after the green wire is cut",
    ),
    "fate": (
        "failsafe-detonated.svg",
        "Illustration of the failsafe detonating after fate decides",
    ),
    "backrooms": ("backrooms.svg", "Illustration of the endless Backrooms"),
    "reality_stable": (
        "primary-lever.svg",
        "Illustration of the Temporal Engine stabilizing reality",
    ),
    "clearance_granted": (
        "mechanical-squirrel.svg",
        "Illustration of the Mechanical Squirrel granting temporal clearance",
    ),
    "failsafe_disarmed": (
        "primary-lever.svg",
        "Illustration of the facility controls after the failsafe is disarmed",
    ),
    "coffee": (
        "office-breakroom.svg",
        "Illustration of the facility coffee area after the perfect cup ending",
    ),
    "disco": (
        "squirrel-disco.svg",
        "Illustration of mechanical squirrels dancing under a disco ball",
    ),
    "teleport_complete": (
        "teleport-beam.svg",
        "Illustration of the teleporting beam returning you safely",
    ),
    "fate_spared": (
        "primary-lever.svg",
        "Illustration of the failsafe controls after fate spares the facility",
    ),
}
