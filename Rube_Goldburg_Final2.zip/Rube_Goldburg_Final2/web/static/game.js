(() => {
  let audioContext;
  const cues = {
    start: [523, 659],
    continue: [587, 784],
    exit: [392, 311, 233],
    readout: [880, 1175, 880],
    back: [440, 370],
    break: [523, 440],
    secret: [330, 494, 740],
    secret_help: [740, 587, 880],
    pull: [660, 880, 1175],
    tap: [440, 392],
    use_beam: [440, 660, 880, 1320],
    vapuration: [220, 330, 220],
    steam: [260, 340, 220],
    printer: [300, 390, 520],
    red_wire: [880, 1175],
    blue_wire: [220, 165],
    green_wire: [220, 165],
    fate: [523, 784],
    print: [600, 440, 600],
    search: [740, 988],
    squirrel: [660, 880],
    red_button: [180, 130],
    tools: [360, 480],
    power: [180, 240, 360],
    vent: [260, 390],
    cubicles: [520, 620],
    meeting: [440, 550],
    coffee_machine: [620, 740, 880],
    microwave: [440, 520],
    fridge: [310, 390],
    recover: [520, 880, 1320],
    left_button: [180, 140, 90],
    right_button: [523, 659, 784],
    disco: [659, 784, 988, 1175],
    wall: [440, 330, 220],
    door: [480, 430],
    floor: [220, 180],
    weekday: [523, 659, 784],
    training: [320, 340, 300],
    squirrel_help: [660, 740, 880],
    archives: [700, 820, 960],
    maintenance: [260, 390, 320],
    offices: [480, 560],
    explore: [440, 550],
    lever: [390, 520, 740],
    nuke: [180, 240, 360],
    inspect_beam: [440, 660, 880],
    cycle: [390, 520, 650],
    inspect_pipes: [330, 440],
    warning: [440, 330],
    meeting_chair: [480, 560],
    meeting_board: [520, 390],
    paper: [520, 420],
    toner: [430, 350],
    polite: [660, 520],
    select: [920],
    ending_success: [523, 659, 784, 1047],
    ending_failure: [440, 370, 294, 196],
    exit_game: [392, 330, 262]
  };
  const profiles = {
    start: ["sine", .12, .12],
    continue: ["sine", .12, .12],
    exit: ["triangle", .18, .16],
    readout: ["sine", .1, .1],
    back: ["triangle", .1, .11],
    break: ["sine", .12, .12],
    secret: ["sawtooth", .13, .14],
    secret_help: ["sine", .1, .12],
    select: ["square", .035, .06],
    pull: ["triangle", .095, .14],
    tap: ["triangle", .1, .12],
    lever: ["triangle", .09, .12],
    search: ["triangle", .07, .12],
    archive: ["triangle", .07, .12],
    archives: ["triangle", .07, .12],
    print: ["square", .055, .09],
    paper: ["square", .055, .08],
    toner: ["square", .055, .08],
    polite: ["square", .06, .1],
    steam: ["sawtooth", .17, .11],
    vapuration: ["sawtooth", .17, .12],
    tools: ["triangle", .1, .11],
    power: ["square", .12, .12],
    vent: ["sine", .14, .1],
    coffee_machine: ["triangle", .11, .13],
    microwave: ["sine", .13, .1],
    fridge: ["sine", .14, .09],
    squirrel: ["sine", .065, .12],
    weekday: ["sine", .1, .13],
    squirrel_help: ["sine", .08, .12],
    left_button: ["sawtooth", .14, .13],
    right_button: ["triangle", .14, .13],
    red_button: ["sawtooth", .16, .15],
    red_wire: ["triangle", .14, .14],
    blue_wire: ["sawtooth", .18, .13],
    green_wire: ["sawtooth", .18, .13],
    ending_success: ["sine", .14, .2],
    ending_failure: ["sawtooth", .2, .17],
    exit_game: ["sine", .16, .18]
  };

  function playSound(action) {
    const AudioContextType = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextType) return;

    try {
      audioContext ||= new AudioContextType();
      if (audioContext.state === "suspended") {
        audioContext.resume().catch((error) => console.warn("Audio could not resume:", error));
      }

      const notes = cues[action];
      if (!notes) {
        console.warn(`No sound cue is configured for action: ${action}`);
        return;
      }
      const [waveform, noteLength, spacing] = profiles[action] || ["sine", .12, .085];
      notes.forEach((frequency, index) => {
        const start = audioContext.currentTime + index * spacing;
        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();
        oscillator.type = waveform;
        oscillator.frequency.setValueAtTime(frequency, start);
        gain.gain.setValueAtTime(.0001, start);
        gain.gain.exponentialRampToValueAtTime(.055, start + .012);
        gain.gain.exponentialRampToValueAtTime(.0001, start + noteLength);
        oscillator.connect(gain);
        gain.connect(audioContext.destination);
        oscillator.start(start);
        oscillator.stop(start + noteLength + .01);
      });
    } catch (error) {
      console.warn("Sound effects could not be played:", error);
    }
  }

  document.addEventListener("submit", async (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.action !== location.origin + "/action") return;
    event.preventDefault();

    const button = event.submitter;
    if (!(button instanceof HTMLButtonElement)) return;
    button.disabled = true;
    button.classList.add("selected");
    playSound(button.value);
    if (button.value === "exit" || button.value === "exit_game") {
      window.close();
      if (window.closed) return;
    }

    const payload = new URLSearchParams({ action: button.value });
    try {
      const response = await fetch(form.action, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
        body: payload
      });
      if (!response.ok) throw new Error(`Server returned ${response.status}`);

      const screenUrl = new URL(response.url);
      const nextDocument = new DOMParser().parseFromString(await response.text(), "text/html");
      const nextMain = nextDocument.querySelector("main");
      if (!nextMain) throw new Error("The game response was incomplete.");
      const expectedPath = `/screen/${nextMain.dataset.scene}`;
      if (screenUrl.origin !== location.origin || screenUrl.pathname !== expectedPath) {
        throw new Error("The game response redirected to an unexpected page.");
      }
      if (nextMain.dataset.scene === "ending" || nextMain.dataset.scene === "backrooms") {
        playSound(nextMain.dataset.endingType === "ending" ? "ending_success" : "ending_failure");
      }
      location.assign(screenUrl.href);
    } catch (error) {
      console.error("Could not change game scene:", error);
      const status = document.getElementById("web-error");
      status.textContent = "The game could not complete that action. Check that the local server is still running, then try again.";
      status.hidden = false;
      button.disabled = false;
    }
  });
})();
