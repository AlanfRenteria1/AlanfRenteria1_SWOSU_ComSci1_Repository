from imports import (
    Callable,
    ERROR_CHOICE_5,
    MenuOption,
    RED,
    RESET,
    YELLOW,
    clear_screen,
    enter_backrooms,
    enter_nuke_room,
    enter_secret_room,
    game_over,
    pull_lever,
    say,
    say_color,
    select_option,
    show_ending,
    sound_effect,
    sys,
    talk_to_squirrel,
    visit_archives,
    visit_maintenance,
    visit_offices,
    visit_wrong_place,
)


START_MENU: list[MenuOption] = [
    {"id": "lever", "name": "Inspect the Primary Lever", "key": "1"},
    {"id": "squirrel", "name": "Talk to the Mechanical Squirrel", "key": "2"},
    {"id": "explore", "name": "Explore the Facility", "key": "3"},
    {"id": "red_button", "name": "Push the Giant Red Button", "key": "4"},
    {"id": "exit", "name": "Exit the facility", "key": "E"},
]

EXPLORE_MENU: list[MenuOption] = [
    {"id": "archives", "name": "Visit the Squirrel Archives", "key": "1"},
    {"id": "maintenance", "name": "Visit the Maintenance Hall", "key": "2"},
    {"id": "offices", "name": "Visit the Offices", "key": "3"},
    {"id": "nuke_room", "name": "Enter the Nuclear Failsafe Chamber", "key": "4"},
    {"id": "start", "name": "Return to the facility entrance", "key": "5"},
]


def explore():
    while True:
        selected_id = select_option("Exploration Wing", EXPLORE_MENU)
        if selected_id is None:
            print(ERROR_CHOICE_5)
            continue
        return selected_id


def show_squirrel_help():
    say("\nThe squirrels take over the lever.")
    say("They do a much better job than you.")
    return "start"


def show_training():
    say("\nYou are sent to Temporal Safety Training.")
    say("There are many slides.")
    say("None of them explain anything.")
    return "start"


def show_coffee():
    return show_ending(
        "A PERFECT CUP OF COFFEE",
        "Time stabilizes. Probably.",
        success=True,
    )


def show_disco():
    return show_ending(
        "THE GREAT SQUIRREL DISCO",
        "Squirrels begin synchronized dancing. Against all odds, reality holds.",
        success=True,
    )


def show_nuke_safe():
    return show_ending(
        "FAILSAFE DISARMED",
        "The failsafe shuts down. Reality continues.",
        success=True,
    )


START_ACTIONS: dict[str, Callable[[], str]] = {
    "lever": pull_lever,
    "squirrel": talk_to_squirrel,
    "explore": explore,
}

STATE_HANDLERS: dict[str, Callable[[], str]] = {
    "archives": visit_archives,
    "maintenance": visit_maintenance,
    "offices": visit_offices,
    "secret_room": enter_secret_room,
    "nuke_room": enter_nuke_room,
    "squirrel": talk_to_squirrel,
    "squirrel_help": show_squirrel_help,
    "training": show_training,
    "coffee": show_coffee,
    "disco": show_disco,
    "nuke_safe": show_nuke_safe,
    "wrong_place": visit_wrong_place,
    "backrooms": enter_backrooms,
}


def main():
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    clear_screen()
    say_color("Welcome to the Temporal Calculation Facility!", YELLOW)

    state = "start"

    while True:
        if state == "start":
            selected_id = select_option("Where do you begin?", START_MENU)
            if selected_id is None:
                print(ERROR_CHOICE_5)
            elif selected_id == "exit":
                say("\nYou leave the facility. Reality remains… mostly intact.")
                break
            elif selected_id == "red_button":
                sound_effect("button")
                state = game_over("You pushed the Giant Red Button.")
            else:
                state = START_ACTIONS[selected_id]()
            continue

        handler = STATE_HANDLERS.get(state)
        if handler is None:
            print(RED + "❌ Unknown state. Returning to start." + RESET)
            state = "start"
        else:
            state = handler()


if __name__ == "__main__":
    main()
