"""Imports shared by the terminal game's entry point."""

import sys
from collections.abc import Callable

from areas.areas.Nuke_Room import enter_nuke_room
from areas.areas.archives import visit_archives
from areas.areas.glitch_spaces import enter_backrooms, visit_wrong_place
from areas.areas.lever import pull_lever
from areas.areas.maintenance import visit_maintenance
from areas.areas.offices import visit_offices
from areas.areas.special_rooms import enter_secret_room
from areas.areas.squirrel import talk_to_squirrel
from core.constants import ERROR_CHOICE_5, RED, RESET, YELLOW
from core.game_logic import game_over
from core.menus import MenuOption, select_option
from core.ui import say, say_color, show_ending, sound_effect
from core.utilities import clear_screen

__all__ = [
    "Callable",
    "ERROR_CHOICE_5",
    "MenuOption",
    "RED",
    "RESET",
    "YELLOW",
    "clear_screen",
    "enter_backrooms",
    "enter_nuke_room",
    "enter_secret_room",
    "game_over",
    "pull_lever",
    "say",
    "say_color",
    "select_option",
    "show_ending",
    "sound_effect",
    "sys",
    "talk_to_squirrel",
    "visit_archives",
    "visit_maintenance",
    "visit_offices",
    "visit_wrong_place",
]
