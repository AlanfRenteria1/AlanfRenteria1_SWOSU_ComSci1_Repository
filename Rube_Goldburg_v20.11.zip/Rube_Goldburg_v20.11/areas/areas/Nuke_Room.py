import random
import time

from core.constants import ERROR_CHOICE_4, PROMPT_SELECTION, RED, RESET, YELLOW
from core.game_logic import game_over
from core.ui import read_selection, say, say_color, show_ending, sound_alarm, sound_effect
from core.utilities import clear_screen


def enter_nuke_room():
    clear_screen()
    sound_alarm()

    say("\nYou enter the Nuclear Failsafe Chamber.")
    say("A very suspicious failsafe device sits in the center of the room.")

    print(RED + r"""
╔════════════════════════════════════════════╗
║              FAILSAFE DEVICE               ║
╠════════════════════════════════════════════╣
║                                            ║
║      [ RED ]   [ BLUE ]   [ GREEN ]        ║
║                                            ║
╚════════════════════════════════════════════╝
""" + RESET)

    say_color("\n⚠ COUNTDOWN INITIATED ⚠", YELLOW)

    for number in range(10, 0, -1):
        print(RED + f"Countdown: {number}" + RESET)
        time.sleep(0.4)

    while True:
        print("\nWhich wire do you cut?")
        print("1 - Red")
        print("2 - Blue")
        print("3 - Green")
        print("4 - Let fate decide")

        choice = read_selection(PROMPT_SELECTION)

        if choice == "1":
            sound_effect("button")
            say("\nYou cut the RED wire.")
            return show_ending(
                "FAILSAFE DISARMED",
                "The red wire was correct. The countdown stops and reality continues.",
                success=True,
            )
        elif choice == "2":
            sound_effect("button")
            say("\nYou cut the BLUE wire.")
            return game_over("The failsafe detonated.")
        elif choice == "3":
            sound_effect("button")
            say("\nYou cut the GREEN wire.")
            return game_over("The failsafe detonated in a very dramatic way.")
        elif choice == "4":
            sound_effect("button")
            say("\nYou step back.")
            say("You let fate decide.")
            if random.random() < 0.5:
                return show_ending(
                    "FATE SPARED THE FACILITY",
                    "Somehow, the failsafe shuts down on its own.",
                    success=True,
                )
            else:
                return game_over("The device explodes in a very bureaucratic way.")
        else:
            print(ERROR_CHOICE_4)
