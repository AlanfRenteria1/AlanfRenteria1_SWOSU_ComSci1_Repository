import random
import time

from core.ui import (
    say,
    say_color,
    beep,
    fast_beep,
    read_selection,
    show_ending,
    sound_effect,
)

from core.constants import (
    ERROR_CHOICE_4,
    ERROR_CHOICE_5,
    HEADER_MAINTENANCE,
    PROMPT_SELECTION,
    RED,
    YELLOW,
)

from assets.ascii_art import (
    POWER_BOX_ART,
    STEAM_PIPE_ART,
    VAPURATION_WARNING_ART,
    MAINTENANCE_HALL_ART,
    TOOL_WALL_ART,
    VENT_ART,
)

from core.events import random_event


def inspect_tool_wall():
    sound_effect("machinery")
    say("\n🔧 You approach a wall covered in maintenance tools.")
    print(TOOL_WALL_ART)
    say("Every tool has a label.")
    say("None of the labels are helpful.")

    tools = [
        "Emergency Temporal Hammer",
        "Left-Handed Screwdriver",
        "Squirrel-Sized Wrench",
        "Quantum Plunger",
        "Backup Backup Hammer",
        "Pipe Encouragement Stick",
        "Absolutely Normal Crowbar"
    ]

    tool = random.choice(tools)
    say_color(f"\nYou pick up the '{tool}'.", YELLOW)
    say("You have no idea what you would use it for.")


def read_vapuration_warning():
    say("\nYou wipe several years of dust off the warning label.")
    print(VAPURATION_WARNING_ART)
    say("Someone has written underneath:")
    say_color("'Surely they don't mean ME.'", YELLOW)


def press_vapuration():
    sound_effect("button")
    say("\nYou press the VAPURATION button.")
    beep()
    say("Nothing happens.")
    time.sleep(1)
    say("Still nothing.")
    time.sleep(1)
    say("You begin to suspect the button is broken.")

    fast_beep()
    say_color("\n⚠ VAPURATION SEQUENCE STARTED ⚠", RED)

    say("Every valve in the room opens at once.")
    say("A completely unreasonable cloud of steam fills the room.")
    say("For a brief moment, you regret several recent decisions.")

    say_color("\n♨ FWHOOSSSHHH! ♨", RED)
    return show_ending(
        "VAPURATION COMPLETE",
        "Every valve opens at once. The steam wins this round.",
    )


def inspect_steam_pipes():
    sound_effect("steam")
    say("\n♨ You approach the Steam Pipe Control Area.")
    say("A maze of pipes covers the wall.")
    say("Gauges shake for reasons nobody bothered to document.")
    say("In the center is a large yellow button.")

    print(STEAM_PIPE_ART)

    while True:
        print("\nWhat do you do?")
        print("1 - Press VAPURATION")
        print("2 - Inspect the pipes")
        print("3 - Read the warning label")
        print("4 - Back away")

        choice = read_selection(PROMPT_SELECTION)

        if choice == "1":
            return press_vapuration()
        elif choice == "2":
            sound_effect("steam")
            say("\nYou inspect the pipes.")
            say("One pipe is marked 'STEAM.'")
            say("Another is marked 'MORE STEAM.'")
            say("The largest pipe is marked 'TOO MUCH STEAM.'")
        elif choice == "3":
            sound_effect("machinery")
            read_vapuration_warning()
        elif choice == "4":
            return "maintenance"
        else:
            print(ERROR_CHOICE_4)


def inspect_power_box():
    sound_effect("machinery")
    say("\n⚡ You approach the Maintenance Power Box.")
    say("It contains dozens of switches.")
    say("Most have sensible labels.")
    say("One does not.")
    print(POWER_BOX_ART)
    say("You decide not to touch the Reality switch.")


def inspect_vent():
    sound_effect("machinery")
    say("\nYou crouch beside a maintenance vent.")
    print(VENT_ART)
    say("Something moves inside.")
    time.sleep(1)
    say("Two tiny glowing eyes appear.")
    say("A mechanical squirrel crawls out.")
    say("It is wearing a miniature maintenance helmet.")
    say("It hands you a work order.")
    say_color("\nWORK ORDER: Stop touching things.", YELLOW)
    say("The squirrel crawls back into the vent.")


def visit_maintenance():
    say("\n🔧 You enter the Maintenance Hall.")
    print(MAINTENANCE_HALL_ART)
    say("Pipes, wires, gauges, and questionable machinery cover every wall.")
    say("A loud metallic CLANK echoes somewhere above you.")

    random_event()

    while True:
        print(HEADER_MAINTENANCE)
        print("1 - Inspect the Steam Pipes")
        print("2 - Inspect the Tool Wall")
        print("3 - Inspect the Power Box")
        print("4 - Inspect the Maintenance Vent")
        print("5 - Return to the Exploration Wing")

        choice = read_selection(PROMPT_SELECTION)

        if choice == "1":
            return inspect_steam_pipes()
        elif choice == "2":
            inspect_tool_wall()
        elif choice == "3":
            inspect_power_box()
        elif choice == "4":
            inspect_vent()
        elif choice == "5":
            say("\nYou leave the Maintenance Hall.")
            return "explore"
        else:
            print(ERROR_CHOICE_5)
