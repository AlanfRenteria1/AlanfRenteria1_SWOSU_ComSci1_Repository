"""Shared terminal game rules."""

from core.ui import show_ending


def game_over(message: str) -> str:
    """Show the ending and return control to the facility start."""
    return show_ending("REALITY RESET REQUIRED", message)
