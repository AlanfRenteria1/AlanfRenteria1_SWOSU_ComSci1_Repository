"""Console text and sound effects shared by the terminal game."""

import sys
import time

from core.constants import BLUE, CYAN, GREEN, MAGENTA, RED, RESET, YELLOW

try:
    import winsound
except ImportError:
    winsound = None


def say(text, delay=0.75):
    """Print a line and preserve the original game's pacing."""
    print(text, flush=True)
    if delay > 0:
        time.sleep(delay)


def say_color(text, color, delay=0.75):
    say(color + text + RESET, delay)


def read_selection(prompt="\nSelection: "):
    """Read an option and show a brief confirmation animation."""
    choice = input(prompt).strip()
    if choice:
        for frame in ("·", "··", "···"):
            sys.stdout.write(f"\r{CYAN}  Processing choice{frame}{RESET}")
            sys.stdout.flush()
            time.sleep(0.035)
        sys.stdout.write(f"\r{GREEN}  ✓ Choice locked in.{RESET}                  \n")
        sys.stdout.flush()
    return choice


def sound_effect(effect):
    """Play a short category-specific sound effect in supported terminals."""
    patterns = {
        "lever": ((390, 55), (520, 55), (740, 100)),
        "button": ((880, 45), (520, 80)),
        "archive": ((720, 45), (540, 45), (820, 80)),
        "printer": ((600, 45), (420, 40), (660, 45), (390, 80)),
        "steam": ((240, 110), (330, 130), (210, 150)),
        "machinery": ((300, 65), (450, 55), (360, 90)),
        "squirrel": ((950, 45), (1250, 60), (1050, 45)),
        "success": ((523, 90), (659, 90), (784, 140)),
        "failure": ((440, 100), (330, 120), (220, 200)),
    }
    notes = patterns.get(effect)
    if notes is None:
        return
    for frequency, duration_ms in notes:
        _play_tone(frequency, duration_ms)


def show_ending(title, message, success=False):
    """Display an animated terminal ending splash and return to the start."""
    from assets.ascii_art import ENDING_SUCCESS_ART, GAME_OVER_ART

    if success:
        sound_effect("success")
        print(ENDING_SUCCESS_ART)
        color = GREEN
    else:
        sound_effect("failure")
        print(GAME_OVER_ART)
        color = RED
    say_color(f"\n{title}", YELLOW if success else MAGENTA, delay=0)
    say_color(message, color, delay=0)
    input("\nPress ENTER to return to the facility...")
    return "start"


def show_game_over(message):
    """Display the shared terminal game-over screen and return to the start."""
    return show_ending("REALITY RESET REQUIRED", message)


def _play_tone(frequency, duration_ms):
    if winsound is not None:
        winsound.Beep(frequency, duration_ms)
    else:
        sys.stdout.write("\a")
        sys.stdout.flush()
        time.sleep(duration_ms / 1000)


def beep():
    """Play a short confirmation tone."""
    _play_tone(880, 180)


def fast_beep():
    """Play three quick alert tones."""
    for frequency in (880, 1047, 1319):
        _play_tone(frequency, 90)
        time.sleep(0.045)


def sound_alarm():
    """Play a three-pulse rising alarm and print its text equivalent."""
    print(RED + "WEEEOOO WEEEOOO WEEEOOO" + RESET, flush=True)
    for _ in range(3):
        _play_tone(740, 180)
        _play_tone(988, 220)
        time.sleep(0.08)
