"""Browser game package."""
