"""Distinct browser game-over messages and effects."""


ENDING_DETAILS = {
    "default": (
        "Reality Reset Required",
        "The timeline has reached an unexpected conclusion. Reality needs a reset.",
    ),
    "red_button": (
        "Reality Reset Required",
        "You pushed the Giant Red Button. The facility has filed a complaint with causality.",
    ),
    "vapuration": (
        "Vapuration Complete",
        "Every valve opened at once. The steam won this round.",
    ),
    "squirrel_doomsday": (
        "Squirrel Doomsday",
        "Mechanical squirrels swarm the room. Reality is now under new management.",
    ),
    "blue_wire": (
        "Failsafe Detonated",
        "You cut the blue wire. The failsafe did exactly what the warning said.",
    ),
    "green_wire": (
        "Failsafe Detonated",
        "You cut the green wire. The explosion was, unfortunately, very dramatic.",
    ),
    "fate": (
        "Fate Has Decided",
        "The device explodes in a very bureaucratic manner. The paperwork survives.",
    ),
    "backrooms": (
        "Signal Lost",
        "The facility is gone. The yellow halls continue in every direction.",
    ),
    "reality_stable": (
        "Reality Stabilized",
        "The Temporal Engine settles into a steady hum. Reality is safe... for now.",
    ),
    "clearance_granted": (
        "Temporal Clearance Granted",
        "The Mechanical Squirrel accepts your answer. The timeline is secure.",
    ),
    "failsafe_disarmed": (
        "Failsafe Disarmed",
        "The countdown stops. The facility gets to keep existing.",
    ),
    "coffee": (
        "A Perfect Cup of Coffee",
        "The secret-room hatch delivers. Time stabilizes. Probably.",
    ),
    "disco": (
        "The Great Squirrel Disco",
        "Squirrels begin synchronized dancing. Against all odds, reality holds.",
    ),
    "teleport_complete": (
        "Teleport Complete",
        "Your atoms file the correct paperwork and return you to the facility.",
    ),
    "fate_spared": (
        "Fate Spared the Facility",
        "Somehow, the failsafe shuts down on its own.",
    ),
    "closed": (
        "Facility Closed",
        "You have left the facility. You can close this tab or window to exit the game.",
    ),
}
