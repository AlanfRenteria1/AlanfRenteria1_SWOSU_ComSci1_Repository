"""Render browser game sessions into the HTML page template."""

import html
from pathlib import Path

from web.config import ACTION_ART, SCENE_ART
from web.endings import ENDING_DETAILS
from web.models import Page
from web.pages import PAGES


TEMPLATE_PATH = Path(__file__).resolve().parent / "templates" / "page.html"
TEMPLATE = TEMPLATE_PATH.read_text(encoding="utf-8")


def render_page(session: dict[str, str]) -> bytes:
    page: Page = PAGES[session["scene"]]
    scene = session["scene"]
    action = session.get("last_action", "")
    ending_id = session.get("ending_id", "")
    image_name, image_description = ACTION_ART.get(action, SCENE_ART[scene])
    title = page["name"]
    description = page["description"]
    is_ending = scene in {"ending", "backrooms", "closed"}
    if is_ending:
        title, description = ENDING_DETAILS.get(ending_id, ENDING_DETAILS["default"])
        if scene != "closed":
            image_name, image_description = "game-over.svg", "Illustration of a temporal game over"
    message = html.escape(session.get("message", ""))

    choices_html = "".join(
        '<button type="submit" name="action" value="{}">{}</button>'.format(
            html.escape(choice["id"], quote=True),
            html.escape(choice["name"]),
        )
        for choice in page["choices"]
    )
    illustration_html = (
        f'<img class="illustration" src="/Web_Assets/{image_name}" '
        f'alt="{html.escape(image_description, quote=True)}">'
    )
    message_html = f'<p class="message" role="status">{message}</p>' if message else ""
    splash_html = ""
    if is_ending:
        ending_class = "closed" if scene == "closed" else "victory" if ending_id in {
            "reality_stable",
            "clearance_granted",
            "failsafe_disarmed",
            "coffee",
            "disco",
            "teleport_complete",
            "fate_spared",
        } else "game-over"
        splash_label = {
            "victory": "TEMPORAL SYSTEMS STABLE",
            "closed": "FACILITY CLOSED",
            "game-over": "TIMELINE ENDED",
        }[ending_class]
        splash_html = (
            f'<section class="end-splash {ending_class}" aria-live="polite">'
            '<span class="splash-orbit" aria-hidden="true"><span></span></span>'
            f'<p class="splash-label">{splash_label}</p>'
            "</section>"
        )

    replacements = {
        "{{title}}": html.escape(title),
        "{{description}}": html.escape(description),
        "{{scene_id}}": html.escape(page["id"], quote=True),
        "{{action_id}}": html.escape(action, quote=True),
        "{{ending_id}}": html.escape(ending_id, quote=True),
        "{{ending_splash}}": splash_html,
        "{{illustration}}": illustration_html,
        "{{message}}": message_html,
        "{{choices}}": choices_html,
    }
    document = TEMPLATE
    for placeholder, value in replacements.items():
        document = document.replace(placeholder, value)
    return document.encode("utf-8")
