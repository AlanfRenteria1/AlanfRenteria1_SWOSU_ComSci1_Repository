Rube_Goldburg_v20.11 — Temporal Calculation Facility

This version adds distinct terminal and browser ending splash screens with
success/failure sound cues, and procedural sound effects for levers, buttons,
archives, printers, steam pipes, machinery, and the mechanical squirrels.
The browser exit flow attempts to close the tab and otherwise displays clear
instructions for closing it manually.

Requirements:
- Python 3
- No third-party packages

Run the browser version:
1. Extract the project ZIP.
2. Open the extracted Rube_Goldburg_v20.11 folder.
3. Double-click run_web.bat, or open PowerShell in this folder and run:
   python web_app.py
4. The game opens at http://127.0.0.1:8000. If it does not open automatically,
   paste that address into your browser.
5. Keep the terminal window open while playing. Press Ctrl+C there to stop.

The original terminal version can still be started with: python main.py

Browser illustrations are stored separately in the Web_Assets folder as SVG
files and are served locally. Browser code is organized under the web folder;
the HTML template and browser styles/scripts are kept in their own folders.
web_app.py remains the browser launch entry point.

The browser version includes animated scene transitions and synthesized sound
effects. The terminal version uses system tones on Windows and the terminal
bell on other platforms.
